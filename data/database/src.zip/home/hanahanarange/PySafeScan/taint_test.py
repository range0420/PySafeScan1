# 案例 A：应该报警（污点流转）
cmd = input("Enter command: ")
final_cmd = cmd + " --help"
os.system(final_cmd) 

# 案例 B：不该报警（安全路径）
safe_cmd = "ls -l"
os.system(safe_cmd)
