#!/usr/bin/env python3
"""专门调试测试4：字符串操作传播"""

import ast
import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

from src.core.taint_analysis_fixed import FixedTaintAnalyzer

# 测试4的代码
test4_code = '''
cmd = input("命令: ")
clean_cmd = cmd.strip()
os.system(clean_cmd)
'''

print("🔍 调试测试4：字符串操作传播")
print("代码:")
print(test4_code)

# 手动解析AST
tree = ast.parse(test4_code)
print("\n=== AST结构 ===")
print(ast.dump(tree, indent=2))

print("\n=== 手动追踪分析 ===")

# 创建分析器
analyzer = FixedTaintAnalyzer()

# 设置parent
for node in ast.walk(tree):
    for child in ast.iter_child_nodes(node):
        child.parent = node

# 手动遍历AST
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        func_name = analyzer._get_full_function_name(node.func)
        print(f"\n发现函数调用: {func_name} (第{node.lineno}行)")
        
        # 检查函数类型
        if analyzer._is_source_function(func_name):
            print(f"  → 是污点源: {func_name}")
            
            # 检查赋值
            if hasattr(node, 'parent') and isinstance(node.parent, ast.Assign):
                print(f"  → 被赋值给变量")
                for target in node.parent.targets:
                    if isinstance(target, ast.Name):
                        print(f"  → 变量名: {target.id}")
        
        elif analyzer._is_sink_function(func_name):
            print(f"  → 是危险函数: {func_name}")
            
            # 检查参数
            for i, arg in enumerate(node.args):
                print(f"  → 参数{i}: {ast.dump(arg)}")
                
                # 提取污点变量
                tainted = analyzer._extract_tainted_from_expr(arg)
                print(f"  → 提取到的污点变量: {tainted}")
        
        elif analyzer._is_propagator_function(func_name):
            print(f"  → 是传播函数: {func_name}")
            
            # 检查输入参数
            for arg in node.args:
                tainted = analyzer._extract_tainted_from_expr(arg)
                print(f"  → 输入参数污点: {tainted}")
            
            # 检查是否被赋值
            if hasattr(node, 'parent') and isinstance(node.parent, ast.Assign):
                for target in node.parent.targets:
                    if isinstance(target, ast.Name):
                        print(f"  → 传播结果赋值给: {target.id}")

print("\n=== 完整分析 ===")
result = analyzer.analyze_code(test4_code, "test4.py")
print(f"污点变量数: {result.get('tainted_variables', 0)}")
print(f"漏洞路径: {result.get('vulnerability_paths', [])}")

print("\n=== 当前污点变量 ===")
for var_name, var in analyzer.tainted_vars.items():
    print(f"{var_name}: {var}")

print("\n=== 传播图 ===")
for source, targets in analyzer.propagation_graph.items():
    print(f"{source} → {targets}")
