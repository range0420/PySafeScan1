import os

def vulnerable_function():
    user_input = input("Enter command: ")
    # 这是一个明显的注入漏洞
    os.system("echo " + user_input)

if __name__ == "__main__":
    vulnerable_function()
