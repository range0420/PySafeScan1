#!/usr/bin/env python3
"""更新主分析器以支持反序列化检测"""

# 读取当前文件
with open('src/core/taint_analysis_fixed.py', 'r') as f:
    content = f.read()

# 1. 在source_functions中添加web相关源
web_sources = '''
            # Web输入和反序列化数据
            'get_data': TaintType.SERIALIZED_DATA,
            'get_json': TaintType.SERIALIZEDIZED_DATA,
            'data': TaintType.SERIALIZED_DATA,'''

# 在source_functions字典中插入
if "'request': TaintType.WEB_INPUT" in content:
    # 在request行后插入
    content = content.replace(
        "'request': TaintType.WEB_INPUT,",
        "'request': TaintType.WEB_INPUT,\n            # Web输入和反序列化数据\n            'get_data': TaintType.SERIALIZED_DATA,\n            'get_json': TaintType.SERIALIZED_DATA,\n            'data': TaintType.SERIALIZED_DATA,"
    )

# 2. 添加TaintType枚举值
if "class TaintType(Enum):" in content:
    # 在枚举中添加SERIALIZED_DATA
    content = content.replace(
        "    PARAMETER = \"parameter\"",
        "    PARAMETER = \"parameter\"\n    SERIALIZED_DATA = \"serialized_data\""
    )

# 3. 确保pickle.loads在sink_functions中
if "'pickle.loads': 'deserialization'" not in content:
    # 在sink_functions中添加
    if "self.sink_functions = {" in content:
        content = content.replace(
            "'pickle.loads': 'deserialization',",
            "'pickle.loads': 'deserialization',\n            'pickle.load': 'deserialization',\n            'pickle.Unpickler': 'deserialization',\n            'pickle.Unpickler.load': 'deserialization',\n            'marshal.loads': 'deserialization',\n            'marshal.load': 'deserialization',\n            'yaml.load': 'deserialization',\n            'yaml.full_load': 'deserialization',"
        )

# 4. 改进visit_Attribute方法来处理request.get_data
if "def visit_Attribute(self, node: ast.Attribute):" in content:
    # 找到这个方法并增强
    import re
    pattern = r'def visit_Attribute\(self, node: ast\.Attribute\):(.*?)(?=\n    def|\n\n)'
    
    def enhance_visit_attribute(match):
        method_body = match.group(1)
        enhanced_body = '''
        """Handle attribute access like sys.argv and request.get_data"""
        # Check for sys.argv
        if node.attr == 'argv':
            # Check if the object is 'sys'
            if isinstance(node.value, ast.Name) and node.value.id == 'sys':
                # Mark this as a taint source
                parent = getattr(node, 'parent', None)
                
                if isinstance(parent, ast.Subscript):
                    # Case: sys.argv[1] - array access
                    subscript_parent = getattr(parent, 'parent', None)
                    if isinstance(subscript_parent, ast.Assign):
                        for target in subscript_parent.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id
                                self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                                print(f"[SOURCE-SYS] {var_name} <- sys.argv (command_line)")
                elif isinstance(parent, ast.Assign):
                    # Case: args = sys.argv
                    for target in parent.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id
                            self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                            print(f"[SOURCE-SYS] {var_name} <- sys.argv (command_line)")
        
        # Check for request.get_data, request.data etc.
        if isinstance(node.value, ast.Name):
            if node.value.id in ['request', 'flask', 'django']:
                if node.attr in ['get_data', 'data', 'get_json', 'args', 'form']:
                    # Mark this attribute access
                    parent = getattr(node, 'parent', None)
                    if isinstance(parent, ast.Call):
                        # Function call, will be handled in visit_Call
                        pass
                    elif isinstance(parent, ast.Assign):
                        # Direct assignment
                        for target in parent.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id
                                taint_type = TaintType.WEB_INPUT
                                if node.attr in ['get_data', 'data', 'get_json']:
                                    taint_type = TaintType.SERIALIZED_DATA
                                self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, taint_type)
                                print(f"[SOURCE-WEB] {var_name} <- request.{node.attr} ({taint_type.value})")
        
        # Continue with normal visitation'''
        
        return 'def visit_Attribute(self, node: ast.Attribute):' + enhanced_body
    
    content = re.sub(pattern, enhance_visit_attribute, content, flags=re.DOTALL)

# 写回文件
with open('src/core/taint_analysis_fixed.py', 'w') as f:
    f.write(content)

print("✅ 已更新分析器以支持反序列化检测")

# 测试更新
print("\n测试反序列化检测...")

test_code = '''
import pickle
from flask import request

def vulnerable():
    data = request.get_data()
    obj = pickle.loads(data)
    return obj
'''

# 直接导入测试
import ast
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional, Any

# 定义必要的类
class TaintType(Enum):
    USER_INPUT = "user_input"
    COMMAND_LINE = "command_line"
    WEB_INPUT = "web_input"
    ENVIRONMENT = "environment"
    FILE_INPUT = "file_input"
    NETWORK = "network"
    PROPAGATED = "propagated"
    PARAMETER = "parameter"
    SERIALIZED_DATA = "serialized_data"

@dataclass
class TaintVariable:
    name: str
    line: int
    type: TaintType
    sources: List[str] = field(default_factory=list)

import importlib.util
spec = importlib.util.spec_from_file_location("FixedTaintAnalyzer", "src/core/taint_analysis_fixed.py")
module = importlib.util.module_from_spec(spec)
module.TaintType = TaintType
module.TaintVariable = TaintVariable
spec.loader.exec_module(module)

analyzer = module.FixedTaintAnalyzer()
result = analyzer.analyze_code(test_code, 'test.py')

print(f"污点变量: {result.get('tainted_variables', 0)}")
print(f"漏洞路径: {len(result.get('vulnerability_paths', []))}")

if result.get('vulnerability_paths'):
    print("✅ 反序列化漏洞检测成功!")
else:
    print("❌ 反序列化漏洞检测失败")
