#!/usr/bin/env python3
"""重建污点分析器，修复所有问题"""

import ast
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

class TaintType(Enum):
    """污点类型枚举"""
    USER_INPUT = "user_input"
    COMMAND_LINE = "command_line"
    WEB_INPUT = "web_input"
    ENVIRONMENT = "environment"
    FILE_INPUT = "file_input"
    NETWORK = "network"
    PROPAGATED = "propagated"
    PARAMETER = "parameter"

@dataclass
class TaintVariable:
    """污点变量"""
    name: str
    line: int
    type: TaintType
    sources: List[str] = field(default_factory=list)
    
    def to_dict(self):
        return {
            'name': self.name,
            'line': self.line,
            'type': self.type.value,
            'sources': self.sources
        }

class FixedTaintAnalyzer(ast.NodeVisitor):
    """修复版污点分析器 - 稳定工作版"""
    
    def __init__(self):
        super().__init__()
        
        # 污点源定义
        self.source_functions = {
            'input': TaintType.USER_INPUT,
            'raw_input': TaintType.USER_INPUT,
            'argv': TaintType.COMMAND_LINE,
            'sys.argv': TaintType.COMMAND_LINE,
            'get': TaintType.WEB_INPUT,
            'post': TaintType.WEB_INPUT,
            'request': TaintType.WEB_INPUT,
            'args': TaintType.WEB_INPUT,
            'form': TaintType.WEB_INPUT,
            'environ': TaintType.ENVIRONMENT,
            'os.environ': TaintType.ENVIRONMENT,
            'getenv': TaintType.ENVIRONMENT,
            'os.getenv': TaintType.ENVIRONMENT,
            'read': TaintType.FILE_INPUT,
            'open': TaintType.FILE_INPUT,
            'recv': TaintType.NETWORK,
            'recvfrom': TaintType.NETWORK,
        }
        
        # 危险函数
        self.sink_functions = {
            'os.system': 'command_injection',
            'os.popen': 'command_injection',
            'os.spawn': 'command_injection',
            'subprocess.call': 'command_injection',
            'subprocess.Popen': 'command_injection',
            'subprocess.run': 'command_injection',
            'subprocess.check_call': 'command_injection',
            'subprocess.check_output': 'command_injection',
            'eval': 'code_injection',
            'exec': 'code_injection',
            'compile': 'code_injection',
            '__import__': 'code_injection',
            'pickle.loads': 'deserialization',
            'pickle.load': 'deserialization',
            'yaml.load': 'deserialization',
            'yaml.safe_load': 'deserialization',
            'marshal.loads': 'deserialization',
            'open': 'path_traversal',
            'execfile': 'code_injection',
            'execute': 'sql_injection',
            'cursor.execute': 'sql_injection',
            'sqlite3.connect.execute': 'sql_injection',
        }
        
        # 传播函数
        self.propagator_functions = {
            'format', 'replace', 'strip', 'split', 'join',
            'upper', 'lower', 'encode', 'decode', 'capitalize',
            'title', 'swapcase', 'lstrip', 'rstrip', 'zfill',
            'center', 'ljust', 'rjust', 'expandtabs',
            'removeprefix', 'removesuffix',
        }
        
        # 分析状态
        self.tainted_vars: Dict[str, TaintVariable] = {}
        self.vulnerability_paths: List[List[str]] = []
        self.propagation_graph: Dict[str, List[str]] = {}
        self.current_file = ""
        
        # 为所有节点设置parent
        self._node_parents: Dict[ast.AST, ast.AST] = {}
        
        # 直接调用的临时变量映射
        self._direct_source_nodes: Dict[ast.Call, str] = {}
    
    def analyze_file(self, filepath: str) -> Dict[str, Any]:
        """分析文件"""
        self.current_file = filepath
        self._reset_state()
        
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()
            
            tree = ast.parse(code)
            
            # 设置所有节点的parent
            self._set_parents(tree)
            
            self.visit(tree)
            
            # 处理直接调用漏洞
            self._process_direct_vulnerabilities()
            
            return self._generate_report()
            
        except Exception as e:
            print(f"[ERROR] 污点分析失败 {filepath}: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def analyze_code(self, code: str, filename: str = "<string>") -> Dict[str, Any]:
        """分析代码字符串"""
        self.current_file = filename
        self._reset_state()
        
        try:
            tree = ast.parse(code)
            self._set_parents(tree)
            self.visit(tree)
            
            # 处理直接调用漏洞
            self._process_direct_vulnerabilities()
            
            return self._generate_report()
        except Exception as e:
            print(f"[ERROR] 污点分析失败: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def _set_parents(self, tree: ast.AST):
        """为AST所有节点设置parent引用"""
        for parent in ast.walk(tree):
            for child in ast.iter_child_nodes(parent):
                self._node_parents[child] = parent
                child.parent = parent  # 动态添加parent属性
    
    def visit_Call(self, node: ast.Call):
        """分析函数调用 - 核心逻辑"""
        # 获取完整函数名
        func_name = self._get_full_function_name(node.func)
        
        if not func_name:
            self.generic_visit(node)
            return
        
        # 检查是否是污点源
        source_type = self._is_source_function(func_name)
        if source_type:
            self._process_source(node, func_name, source_type)
        
        # 检查是否是危险函数
        vuln_type = self._is_sink_function(func_name)
        if vuln_type:
            self._process_sink(node, func_name, vuln_type)
        
        # 检查是否是传播函数
        if self._is_propagator_function(func_name):
            self._process_propagator(node, func_name)
        
        # 特殊处理：sys.argv[1] 这样的下标访问
        self._check_sys_argv_access(node)
        
        self.generic_visit(node)
    
    def _check_sys_argv_access(self, node):
        """检查 sys.argv 访问"""
        # 检查是否是属性访问（如 sys.argv）
        if isinstance(node, ast.Attribute):
            if node.attr == 'argv':
                # 检查对象是否是 sys
                if isinstance(node.value, ast.Name) and node.value.id == 'sys':
                    # 标记这个属性访问的父节点（如果被赋值）
                    parent = getattr(node, 'parent', None)
                    if isinstance(parent, ast.Subscript):
                        # sys.argv[1] 的情况
                        parent_parent = getattr(parent, 'parent', None)
                        if isinstance(parent_parent, ast.Assign):
                            for target in parent_parent.targets:
                                if isinstance(target, ast.Name):
                                    var_name = target.id
                                    self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                                    print(f"[SOURCE-SYS] {var_name} ← sys.argv (command_line)")
    
    def _process_source(self, node: ast.Call, func_name: str, taint_type: TaintType):
        """处理污点源"""
        # 检查是否有赋值
        parent = getattr(node, 'parent', None)
        
        if isinstance(parent, ast.Assign):
            for target in parent.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id
                    self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, taint_type)
                    print(f"[SOURCE] {var_name} ← {func_name} ({taint_type.value})")
        else:
            # 处理直接调用（没有赋值的情况）
            temp_var = f"__direct_source_{node.lineno}_{id(node)}"
            self.tainted_vars[temp_var] = TaintVariable(temp_var, node.lineno, taint_type)
            self._direct_source_nodes[node] = temp_var
            print(f"[SOURCE-DIRECT] {temp_var} ← {func_name} ({taint_type.value})")
    
    def _process_direct_vulnerabilities(self):
        """处理直接调用的漏洞"""
        for source_node, temp_var in self._direct_source_nodes.items():
            parent = getattr(source_node, 'parent', None)
            
            if isinstance(parent, ast.Call):
                func_name = self._get_full_function_name(parent.func)
                vuln_type = self._is_sink_function(func_name)
                
                if vuln_type:
                    path = [temp_var, f"{func_name}(arg0)"]
                    self.vulnerability_paths.append(path)
                    print(f"[VULNERABILITY-DIRECT] {vuln_type.upper()} at line {source_node.lineno}")
                    print(f"  Path: {' → '.join(path)}")
    
    def _process_sink(self, node: ast.Call, func_name: str, vuln_type: str):
        """处理危险函数（污点汇聚点）"""
        for i, arg in enumerate(node.args):
            tainted_vars = self._extract_tainted_from_expr(arg)
            
            for tainted_var in tainted_vars:
                path = self._trace_taint_path(tainted_var)
                if path:
                    path.append(f"{func_name}(arg{i})")
                    self.vulnerability_paths.append(path)
                    print(f"[VULNERABILITY] {vuln_type.upper()} at line {node.lineno}")
                    print(f"  Path: {' → '.join(path)}")
    
    def _process_propagator(self, node: ast.Call, func_name: str):
        """处理传播函数"""
        tainted_inputs = []
        for arg in node.args:
            extracted = self._extract_tainted_from_expr(arg)
            tainted_inputs.extend(extracted)
        
        # 对于方法调用，检查调用对象本身
        if isinstance(node.func, ast.Attribute):
            obj_tainted = self._extract_tainted_from_expr(node.func.value)
            tainted_inputs.extend(obj_tainted)
        
        if tainted_inputs:
            parent = getattr(node, 'parent', None)
            if isinstance(parent, ast.Assign):
                for target in parent.targets:
                    if isinstance(target, ast.Name):
                        output_var = target.id
                        self._mark_as_tainted(output_var, node.lineno, TaintType.PROPAGATED, tainted_inputs)
                        print(f"[PROPAGATION] {output_var} ← {func_name}({', '.join(tainted_inputs)})")
    
    def visit_Assign(self, node: ast.Assign):
        """分析赋值语句"""
        tainted_vars = self._extract_tainted_from_expr(node.value)
        
        if tainted_vars:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id
                    self._mark_as_tainted(var_name, node.lineno, TaintType.PROPAGATED, tainted_vars)
        
        self.generic_visit(node)
    
    def visit_AugAssign(self, node: ast.AugAssign):
        """分析增强赋值"""
        if isinstance(node.target, ast.Name):
            var_name = node.target.id
            tainted_vars = self._extract_tainted_from_expr(node.value)
            if tainted_vars:
                self._mark_as_tainted(var_name, node.lineno, TaintType.PROPAGATED, tainted_vars)
        
        self.generic_visit(node)
    
    def _get_full_function_name(self, node) -> str:
        """获取完整函数名"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            parts = []
            current = node
            
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            
            if isinstance(current, ast.Name):
                parts.append(current.id)
            
            parts.reverse()
            return '.'.join(parts)
        return ""
    
    def _is_source_function(self, func_name: str) -> Optional[TaintType]:
        """检查是否是污点源函数"""
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        
        for source_func, taint_type in self.source_functions.items():
            if source_func == base_name or source_func == func_name:
                return taint_type
        
        return None
    
    def _is_sink_function(self, func_name: str) -> Optional[str]:
        """检查是否是危险函数"""
        for sink_func, vuln_type in self.sink_functions.items():
            if sink_func == func_name:
                return vuln_type
        
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        for sink_func, vuln_type in self.sink_functions.items():
            sink_base = sink_func.split('.')[-1]
            if sink_base == base_name:
                return vuln_type
        
        return None
    
    def _is_propagator_function(self, func_name: str) -> bool:
        """检查是否是传播函数"""
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        return base_name in self.propagator_functions
    
    def _extract_tainted_from_expr(self, node: ast.AST) -> List[str]:
        """从表达式中提取污点变量"""
        tainted = []
        
        if isinstance(node, ast.Name):
            if node.id in self.tainted_vars:
                tainted.append(node.id)
        
        elif isinstance(node, ast.BinOp):
            tainted.extend(self._extract_tainted_from_expr(node.left))
            tainted.extend(self._extract_tainted_from_expr(node.right))
        
        elif isinstance(node, ast.Call):
            for arg in node.args:
                tainted.extend(self._extract_tainted_from_expr(arg))
            
            func_name = self._get_full_function_name(node.func)
            if self._is_propagator_function(func_name):
                if node.args:
                    tainted.extend(self._extract_tainted_from_expr(node.args[0]))
        
        elif isinstance(node, ast.JoinedStr):
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    tainted.extend(self._extract_tainted_from_expr(value.value))
        
        elif isinstance(node, ast.Subscript):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        elif isinstance(node, ast.UnaryOp):
            tainted.extend(self._extract_tainted_from_expr(node.operand))
        
        elif isinstance(node, ast.Attribute):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        return list(set(tainted))
    
    def _mark_as_tainted(self, var_name: str, line: int, 
                        taint_type: TaintType, sources: List[str]):
        """标记变量为污点"""
        if var_name not in self.tainted_vars:
            self.tainted_vars[var_name] = TaintVariable(var_name, line, taint_type)
        
        for source in sources:
            if source in self.tainted_vars and source not in self.tainted_vars[var_name].sources:
                self.tainted_vars[var_name].sources.append(source)
                
                if source not in self.propagation_graph:
                    self.propagation_graph[source] = []
                if var_name not in self.propagation_graph[source]:
                    self.propagation_graph[source].append(var_name)
    
    def _trace_taint_path(self, start_var: str) -> List[str]:
        """追踪污点传播路径"""
        if start_var not in self.tainted_vars:
            return []
        
        path = [start_var]
        visited = set()
        current = start_var
        
        while current in self.tainted_vars and current not in visited:
            visited.add(current)
            var = self.tainted_vars[current]
            
            if var.sources:
                next_var = var.sources[0]
                if next_var not in visited:
                    path.insert(0, next_var)
                    current = next_var
                else:
                    break
            else:
                break
        
        return path
    
    def _generate_report(self) -> Dict[str, Any]:
        """生成分析报告"""
        sources_found = []
        for var_name, var in self.tainted_vars.items():
            if not var_name.startswith('__direct_source_'):
                sources_found.append(var.to_dict())
        
        graph_edges = []
        for source, targets in self.propagation_graph.items():
            for target in targets:
                if not source.startswith('__direct_source_'):
                    graph_edges.append([source, target])
        
        return {
            'file': self.current_file,
            'tainted_variables': len([v for v in self.tainted_vars if not v.startswith('__direct_source_')]),
            'vulnerability_paths': self.vulnerability_paths,
            'graph_edges': graph_edges,
            'analysis_details': {
                'sources_found': sources_found,
                'sinks_found': len(self.vulnerability_paths),
                'propagation_chains': self._extract_all_chains()
            }
        }
    
    def _extract_all_chains(self) -> List[List[str]]:
        """提取所有传播链"""
        chains = []
        visited = set()
        
        def dfs(current: str, path: List[str]):
            if current in visited:
                return
            
            visited.add(current)
            path.append(current)
            
            if current not in self.propagation_graph or not self.propagation_graph[current]:
                if len(path) > 1:
                    chains.append(path.copy())
            else:
                for next_var in self.propagation_graph[current]:
                    dfs(next_var, path)
            
            path.pop()
        
        all_vars = set(self.tainted_vars.keys())
        vars_with_incoming = set()
        
        for targets in self.propagation_graph.values():
            for target in targets:
                vars_with_incoming.add(target)
        
        sources = all_vars - vars_with_incoming
        
        for source in sources:
            dfs(source, [])
        
        return chains
    
    def _reset_state(self):
        """重置分析状态"""
        self.tainted_vars.clear()
        self.vulnerability_paths.clear()
        self.propagation_graph.clear()
        self._node_parents.clear()
        self._direct_source_nodes.clear()

# 保存到文件
with open('src/core/taint_analysis_fixed.py', 'w') as f:
    f.write(__doc__ + '\n\n')  # 写入模块文档
    f.write('import ast\n')
    f.write('from typing import Dict, List, Set, Tuple, Optional, Any\n')
    f.write('from dataclasses import dataclass, field\n')
    f.write('from enum import Enum\n\n')
    
    # 写入类定义
    import inspect
    source = inspect.getsource(TaintType)
    f.write(source + '\n\n')
    
    source = inspect.getsource(TaintVariable)
    f.write(source + '\n\n')
    
    source = inspect.getsource(FixedTaintAnalyzer)
    f.write(source)

print("✅ 已重建污点分析器")
print("\n现在运行测试验证...")

import subprocess
result = subprocess.run(['python', 'test_taint_fixed.py'], capture_output=True, text=True)
print(result.stdout)
if result.stderr:
    print("错误:", result.stderr)
