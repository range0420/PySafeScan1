#!/usr/bin/env python3
"""修复反序列化漏洞检测"""

import ast
from typing import Dict, List, Set, Tuple, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

class TaintType(Enum):
    """Taint type enumeration"""
    USER_INPUT = "user_input"
    COMMAND_LINE = "command_line"
    WEB_INPUT = "web_input"
    ENVIRONMENT = "environment"
    FILE_INPUT = "file_input"
    NETWORK = "network"
    PROPAGATED = "propagated"
    PARAMETER = "parameter"
    # 添加反序列化相关类型
    SERIALIZED_DATA = "serialized_data"
    NETWORK_DATA = "network_data"

@dataclass
class TaintVariable:
    """Tainted variable"""
    name: str
    line: int
    type: TaintType
    sources: List[str] = field(default_factory=list)
    
    def to_dict(self):
        return {
            'name': self.name,
            'line': self.line,
            'type': self.type.value,
            'sources': self.sources
        }

class EnhancedTaintAnalyzer(ast.NodeVisitor):
    """Enhanced taint analyzer with deserialization support"""
    
    def __init__(self):
        super().__init__()
        
        # 扩展污点源定义
        self.source_functions = {
            'input': TaintType.USER_INPUT,
            'raw_input': TaintType.USER_INPUT,
            'argv': TaintType.COMMAND_LINE,
            'sys.argv': TaintType.COMMAND_LINE,
            # Web输入
            'get': TaintType.WEB_INPUT,
            'post': TaintType.WEB_INPUT,
            'request': TaintType.WEB_INPUT,
            'args': TaintType.WEB_INPUT,
            'form': TaintType.WEB_INPUT,
            'get_data': TaintType.SERIALIZED_DATA,  # 反序列化数据源
            'get_json': TaintType.SERIALIZED_DATA,
            'data': TaintType.SERIALIZED_DATA,
            # 环境变量
            'environ': TaintType.ENVIRONMENT,
            'os.environ': TaintType.ENVIRONMENT,
            'getenv': TaintType.ENVIRONMENT,
            'os.getenv': TaintType.ENVIRONMENT,
            # 文件/网络
            'read': TaintType.FILE_INPUT,
            'open': TaintType.FILE_INPUT,
            'recv': TaintType.NETWORK_DATA,
            'recvfrom': TaintType.NETWORK_DATA,
        }
        
        # 扩展危险函数（特别注意反序列化）
        self.sink_functions = {
            # 命令注入
            'os.system': 'command_injection',
            'os.popen': 'command_injection',
            'os.spawn': 'command_injection',
            'subprocess.call': 'command_injection',
            'subprocess.Popen': 'command_injection',
            'subprocess.run': 'command_injection',
            'subprocess.check_call': 'command_injection',
            'subprocess.check_output': 'command_injection',
            # 代码注入
            'eval': 'code_injection',
            'exec': 'code_injection',
            'compile': 'code_injection',
            '__import__': 'code_injection',
            # 反序列化漏洞 - 重点修复！
            'pickle.loads': 'deserialization',
            'pickle.load': 'deserialization',
            'pickle.Unpickler': 'deserialization',
            'pickle.Unpickler.load': 'deserialization',
            'cPickle.loads': 'deserialization',
            'cPickle.load': 'deserialization',
            'marshal.loads': 'deserialization',
            'marshal.load': 'deserialization',
            'yaml.load': 'deserialization',
            'yaml.full_load': 'deserialization',
            'yaml.unsafe_load': 'deserialization',
            'json.loads': 'deserialization',  # 注意：json相对安全，但仍有风险
            'json.load': 'deserialization',
            'shelve.open': 'deserialization',
            # 路径遍历
            'open': 'path_traversal',
            'execfile': 'code_injection',
            # SQL注入
            'execute': 'sql_injection',
            'cursor.execute': 'sql_injection',
            'executemany': 'sql_injection',
            'sqlite3.connect.execute': 'sql_injection',
            # Web框架特定
            'render_template_string': 'ssti',
            'Template': 'ssti',
        }
        
        # 传播函数
        self.propagator_functions = {
            'format', 'replace', 'strip', 'split', 'join',
            'upper', 'lower', 'encode', 'decode', 'capitalize',
            'title', 'swapcase', 'lstrip', 'rstrip', 'zfill',
            'center', 'ljust', 'rjust', 'expandtabs',
            'removeprefix', 'removesuffix',
        }
        
        # 分析状态
        self.tainted_vars: Dict[str, TaintVariable] = {}
        self.vulnerability_paths: List[List[str]] = []
        self.propagation_graph: Dict[str, List[str]] = {}
        self.current_file = ""
        
        # 设置parent
        self._node_parents: Dict[ast.AST, ast.AST] = {}
        
        # 直接调用临时变量映射
        self._direct_source_nodes: Dict[ast.Call, str] = {}
    
    def analyze_code(self, code: str, filename: str = "<string>") -> Dict[str, Any]:
        """分析代码字符串"""
        self.current_file = filename
        self._reset_state()
        
        try:
            tree = ast.parse(code)
            self._set_parents(tree)
            self.visit(tree)
            
            # 处理直接调用漏洞
            self._process_direct_vulnerabilities()
            
            return self._generate_report()
        except Exception as e:
            print(f"[ERROR] Taint analysis failed: {e}")
            import traceback
            traceback.print_exc()
            return {}
    
    def _set_parents(self, tree: ast.AST):
        """为AST所有节点设置parent引用"""
        for parent in ast.walk(tree):
            for child in ast.iter_child_nodes(parent):
                self._node_parents[child] = parent
                child.parent = parent
    
    def visit_Attribute(self, node: ast.Attribute):
        """处理属性访问"""
        # Check for request.get_data, request.data 等
        if isinstance(node.value, ast.Name):
            if node.value.id in ['request', 'flask', 'django']:
                if node.attr in ['get_data', 'data', 'get_json', 'args', 'form']:
                    # 标记这个属性访问
                    parent = getattr(node, 'parent', None)
                    if isinstance(parent, ast.Call):
                        # 函数调用，会在 visit_Call 中处理
                        pass
                    elif isinstance(parent, ast.Assign):
                        # 直接赋值
                        for target in parent.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id
                                taint_type = TaintType.WEB_INPUT
                                if node.attr in ['get_data', 'data', 'get_json']:
                                    taint_type = TaintType.SERIALIZED_DATA
                                self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, taint_type)
                                print(f"[SOURCE-WEB] {var_name} <- request.{node.attr} ({taint_type.value})")
        
        self.generic_visit(node)
    
    def visit_Call(self, node: ast.Call):
        """分析函数调用"""
        func_name = self._get_full_function_name(node.func)
        
        if not func_name:
            self.generic_visit(node)
            return
        
        # 检查是否是污点源
        source_type = self._is_source_function(func_name)
        if source_type:
            self._process_source(node, func_name, source_type)
        
        # 检查是否是危险函数
        vuln_type = self._is_sink_function(func_name)
        if vuln_type:
            self._process_sink(node, func_name, vuln_type)
        
        # 检查是否是传播函数
        if self._is_propagator_function(func_name):
            self._process_propagator(node, func_name)
        
        self.generic_visit(node)
    
    def _process_source(self, node: ast.Call, func_name: str, taint_type: TaintType):
        """处理污点源"""
        parent = getattr(node, 'parent', None)
        
        if isinstance(parent, ast.Assign):
            for target in parent.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id
                    self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, taint_type)
                    print(f"[SOURCE] {var_name} <- {func_name} ({taint_type.value})")
        else:
            temp_var = f"__direct_source_{node.lineno}_{id(node)}"
            self.tainted_vars[temp_var] = TaintVariable(temp_var, node.lineno, taint_type)
            self._direct_source_nodes[node] = temp_var
            print(f"[SOURCE-DIRECT] {temp_var} <- {func_name} ({taint_type.value})")
    
    def _process_sink(self, node: ast.Call, func_name: str, vuln_type: str):
        """处理危险函数"""
        for i, arg in enumerate(node.args):
            tainted_vars = self._extract_tainted_from_expr(arg)
            
            for tainted_var in tainted_vars:
                path = self._trace_taint_path(tainted_var)
                if path:
                    path.append(f"{func_name}(arg{i})")
                    self.vulnerability_paths.append(path)
                    print(f"[VULNERABILITY] {vuln_type.upper()} at line {node.lineno}")
                    print(f"  Path: {' -> '.join(path)}")
    
    def _process_propagator(self, node: ast.Call, func_name: str):
        """处理传播函数"""
        tainted_inputs = []
        for arg in node.args:
            extracted = self._extract_tainted_from_expr(arg)
            tainted_inputs.extend(extracted)
        
        if isinstance(node.func, ast.Attribute):
            obj_tainted = self._extract_tainted_from_expr(node.func.value)
            tainted_inputs.extend(obj_tainted)
        
        if tainted_inputs:
            parent = getattr(node, 'parent', None)
            if isinstance(parent, ast.Assign):
                for target in parent.targets:
                    if isinstance(target, ast.Name):
                        output_var = target.id
                        self._mark_as_tainted(output_var, node.lineno, TaintType.PROPAGATED, tainted_inputs)
                        print(f"[PROPAGATION] {output_var} <- {func_name}({', '.join(tainted_inputs)})")
    
    def visit_Assign(self, node: ast.Assign):
        """分析赋值语句"""
        tainted_vars = self._extract_tainted_from_expr(node.value)
        
        if tainted_vars:
            for target in node.targets:
                if isinstance(target, ast.Name):
                    var_name = target.id
                    self._mark_as_tainted(var_name, node.lineno, TaintType.PROPAGATED, tainted_vars)
        
        self.generic_visit(node)
    
    def _get_full_function_name(self, node) -> str:
        """获取完整函数名"""
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            parts = []
            current = node
            
            while isinstance(current, ast.Attribute):
                parts.append(current.attr)
                current = current.value
            
            if isinstance(current, ast.Name):
                parts.append(current.id)
            
            parts.reverse()
            return '.'.join(parts)
        return ""
    
    def _is_source_function(self, func_name: str) -> Optional[TaintType]:
        """检查是否是污点源函数"""
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        
        for source_func, taint_type in self.source_functions.items():
            if source_func == base_name or source_func == func_name:
                return taint_type
        
        return None
    
    def _is_sink_function(self, func_name: str) -> Optional[str]:
        """检查是否是危险函数"""
        # 完全匹配
        for sink_func, vuln_type in self.sink_functions.items():
            if sink_func == func_name:
                return vuln_type
        
        # 基础名匹配
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        for sink_func, vuln_type in self.sink_functions.items():
            sink_base = sink_func.split('.')[-1]
            if sink_base == base_name:
                return vuln_type
        
        return None
    
    def _is_propagator_function(self, func_name: str) -> bool:
        """检查是否是传播函数"""
        base_name = func_name.split('.')[-1] if '.' in func_name else func_name
        return base_name in self.propagator_functions
    
    def _extract_tainted_from_expr(self, node: ast.AST) -> List[str]:
        """从表达式中提取污点变量"""
        tainted = []
        
        if isinstance(node, ast.Name):
            if node.id in self.tainted_vars:
                tainted.append(node.id)
        
        elif isinstance(node, ast.BinOp):
            tainted.extend(self._extract_tainted_from_expr(node.left))
            tainted.extend(self._extract_tainted_from_expr(node.right))
        
        elif isinstance(node, ast.Call):
            for arg in node.args:
                tainted.extend(self._extract_tainted_from_expr(arg))
            
            func_name = self._get_full_function_name(node.func)
            if self._is_propagator_function(func_name):
                if node.args:
                    tainted.extend(self._extract_tainted_from_expr(node.args[0]))
        
        elif isinstance(node, ast.JoinedStr):
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    tainted.extend(self._extract_tainted_from_expr(value.value))
        
        elif isinstance(node, ast.Subscript):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        elif isinstance(node, ast.UnaryOp):
            tainted.extend(self._extract_tainted_from_expr(node.operand))
        
        elif isinstance(node, ast.Attribute):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        return list(set(tainted))
    
    def _mark_as_tainted(self, var_name: str, line: int, 
                        taint_type: TaintType, sources: List[str]):
        """标记变量为污点"""
        if var_name not in self.tainted_vars:
            self.tainted_vars[var_name] = TaintVariable(var_name, line, taint_type)
        
        for source in sources:
            if source in self.tainted_vars and source not in self.tainted_vars[var_name].sources:
                self.tainted_vars[var_name].sources.append(source)
                
                if source not in self.propagation_graph:
                    self.propagation_graph[source] = []
                if var_name not in self.propagation_graph[source]:
                    self.propagation_graph[source].append(var_name)
    
    def _trace_taint_path(self, start_var: str) -> List[str]:
        """追踪污点传播路径"""
        if start_var not in self.tainted_vars:
            return []
        
        path = [start_var]
        visited = set()
        current = start_var
        
        while current in self.tainted_vars and current not in visited:
            visited.add(current)
            var = self.tainted_vars[current]
            
            if var.sources:
                next_var = var.sources[0]
                if next_var not in visited:
                    path.insert(0, next_var)
                    current = next_var
                else:
                    break
            else:
                break
        
        return path
    
    def _generate_report(self) -> Dict[str, Any]:
        """生成分析报告"""
        sources_found = []
        for var_name, var in self.tainted_vars.items():
            if not var_name.startswith('__direct_source_'):
                sources_found.append(var.to_dict())
        
        graph_edges = []
        for source, targets in self.propagation_graph.items():
            for target in targets:
                if not source.startswith('__direct_source_'):
                    graph_edges.append([source, target])
        
        return {
            'file': self.current_file,
            'tainted_variables': len([v for v in self.tainted_vars if not v.startswith('__direct_source_')]),
            'vulnerability_paths': self.vulnerability_paths,
            'graph_edges': graph_edges,
        }
    
    def _process_direct_vulnerabilities(self):
        """处理直接调用漏洞"""
        for source_node, temp_var in self._direct_source_nodes.items():
            parent = getattr(source_node, 'parent', None)
            
            if isinstance(parent, ast.Call):
                func_name = self._get_full_function_name(parent.func)
                vuln_type = self._is_sink_function(func_name)
                
                if vuln_type:
                    path = [temp_var, f"{func_name}(arg0)"]
                    self.vulnerability_paths.append(path)
                    print(f"[VULNERABILITY-DIRECT] {vuln_type.upper()} at line {source_node.lineno}")
                    print(f"  Path: {' -> '.join(path)}")
    
    def _reset_state(self):
        """重置分析状态"""
        self.tainted_vars.clear()
        self.vulnerability_paths.clear()
        self.propagation_graph.clear()
        self._node_parents.clear()
        self._direct_source_nodes.clear()

# 测试修复
print("🧪 测试反序列化漏洞检测修复")
print("=" * 60)

test_code = '''
import pickle
import yaml
from flask import request

def load_data():
    data = request.get_data()
    # 危险：反序列化用户输入
    obj = pickle.loads(data)  # 反序列化漏洞
    return str(obj)
'''

analyzer = EnhancedTaintAnalyzer()
result = analyzer.analyze_code(test_code, 'deserialization_test.py')

print(f"\n分析结果:")
print(f"污点变量数: {result.get('tainted_variables', 0)}")
print(f"漏洞路径数: {len(result.get('vulnerability_paths', []))}")

if result.get('vulnerability_paths'):
    print("\n✅ 成功检测到反序列化漏洞!")
    for path in result['vulnerability_paths']:
        print(f"  → {' -> '.join(path)}")
else:
    print("\n❌ 未检测到反序列化漏洞")
    print("污点变量:", list(analyzer.tainted_vars.keys()))
