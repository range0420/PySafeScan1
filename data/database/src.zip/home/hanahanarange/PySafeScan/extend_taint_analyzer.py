#!/usr/bin/env python3
"""扩展污点分析器能力"""

import ast
from src.core.taint_analysis_fixed import FixedTaintAnalyzer

class ExtendedTaintAnalyzer(FixedTaintAnalyzer):
    """扩展版污点分析器"""
    
    def __init__(self):
        super().__init__()
        
        # 扩展污点源
        self.source_functions.update({
            'argv': TaintType.COMMAND_LINE,
            'sys.argv': TaintType.COMMAND_LINE,
            'environ': TaintType.ENVIRONMENT,
            'os.environ': TaintType.ENVIRONMENT,
            'getenv': TaintType.ENVIRONMENT,
            'os.getenv': TaintType.ENVIRONMENT,
            'getcwd': TaintType.FILE_INPUT,
            'os.getcwd': TaintType.FILE_INPUT,
            'listdir': TaintType.FILE_INPUT,
            'os.listdir': TaintType.FILE_INPUT,
        })
        
        # 扩展危险函数（SQL注入相关）
        self.sink_functions.update({
            'execute': 'sql_injection',
            'cursor.execute': 'sql_injection',
            'executemany': 'sql_injection',
            'fetchone': 'sql_injection',  # 虽然不是执行，但可能指示SQL注入风险
            'fetchall': 'sql_injection',
            'fetchmany': 'sql_injection',
            # 添加更多数据库驱动
            'sqlite3.Cursor.execute': 'sql_injection',
            'mysql.connector.execute': 'sql_injection',
            'psycopg2.execute': 'sql_injection',
            'pymysql.execute': 'sql_injection',
        })
        
        # 扩展传播模式（用于检测SQL拼接）
        self.sql_patterns = [
            'format',
            'replace',
            'join',
            '+',  # 字符串连接
            'f-string',  # f-string
        ]
    
    def visit_Call(self, node: ast.Call):
        """重写函数调用分析，添加SQL注入检测"""
        super().visit_Call(node)
        
        # 额外检查SQL注入模式
        self._check_sql_injection(node)
    
    def _check_sql_injection(self, node: ast.Call):
        """检查SQL注入模式"""
        func_name = self._get_full_function_name(node.func)
        
        # 检查是否是数据库操作
        if 'execute' in func_name.lower() or 'cursor' in func_name:
            # 检查所有参数
            for i, arg in enumerate(node.args):
                # 检查参数是否包含污点
                tainted_vars = self._extract_tainted_from_expr(arg)
                
                if tainted_vars:
                    # 检查是否是字符串拼接或格式化
                    if self._is_string_operation(arg):
                        path = []
                        for tainted_var in tainted_vars:
                            var_path = self._trace_taint_path(tainted_var)
                            if var_path:
                                path.extend(var_path)
                        
                        if path:
                            path.append(f"{func_name}(arg{i}) - SQL_INJECTION")
                            self.vulnerability_paths.append(path)
                            print(f"[SQL-INJECTION] 检测到SQL注入风险 at line {node.lineno}")
                            print(f"  Path: {' → '.join(path)}")
    
    def _is_string_operation(self, node: ast.AST) -> bool:
        """检查是否是字符串操作（可能引入SQL注入）"""
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
            return True  # 字符串连接
        
        elif isinstance(node, ast.JoinedStr):
            return True  # f-string
        
        elif isinstance(node, ast.Call):
            func_name = self._get_full_function_name(node.func)
            if 'format' in func_name or 'replace' in func_name:
                return True
        
        return False
    
    def visit_Assign(self, node: ast.Assign):
        """重写赋值分析，检测SQL查询字符串构建"""
        super().visit_Assign(node)
        
        # 检查是否在构建SQL查询字符串
        for target in node.targets:
            if isinstance(target, ast.Name):
                var_name = target.id
                
                # 检查变量名是否包含查询相关关键词
                sql_keywords = ['query', 'sql', 'stmt', 'statement', 'command']
                if any(keyword in var_name.lower() for keyword in sql_keywords):
                    # 检查右侧表达式是否包含污点
                    tainted_vars = self._extract_tainted_from_expr(node.value)
                    
                    if tainted_vars and self._is_string_operation(node.value):
                        # 标记这个变量为潜在的SQL注入风险
                        print(f"[SQL-BUILD] 检测到SQL查询字符串构建: {var_name}")
                        # 可以在这里添加特殊标记或记录

# 测试扩展功能
print("🧪 测试扩展版污点分析器")
print("=" * 60)

test_code = '''
import subprocess
import sys

def process_request():
    # Web框架中常见的不安全模式
    user_cmd = sys.argv[1] if len(sys.argv) > 1 else ''
    
    if user_cmd:
        # 危险：直接执行用户输入
        subprocess.run(user_cmd, shell=True)
    
    # 另一个常见问题：拼接SQL
    user_id = input("用户ID: ")
    query = f"SELECT * FROM users WHERE id = {user_id}"
    # cursor.execute(query)  # 这里应该有SQL注入

process_request()
'''

analyzer = ExtendedTaintAnalyzer()
result = analyzer.analyze_code(test_code, 'extended_test.py')

print(f"\n📊 分析结果:")
print(f"污点变量数: {result.get('tainted_variables', 0)}")
print(f"漏洞路径数: {len(result.get('vulnerability_paths', []))}")

if result.get('vulnerability_paths'):
    print("\n发现的漏洞:")
    for i, path in enumerate(result['vulnerability_paths']):
        print(f"  {i+1}. {' → '.join(path)}")

# 测试sys.argv识别
print("\n" + "=" * 60)
print("测试 sys.argv 识别:")

argv_test = '''
import sys
cmd = sys.argv[1]
print(cmd)  # 这里应该检测到argv是污点源
'''

analyzer2 = ExtendedTaintAnalyzer()
result2 = analyzer2.analyze_code(argv_test, 'argv_test.py')
print(f"sys.argv检测: {'成功' if result2.get('tainted_variables', 0) > 0 else '失败'}")
