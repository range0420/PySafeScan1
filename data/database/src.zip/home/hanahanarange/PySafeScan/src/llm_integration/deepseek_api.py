import os
import json
import time
from openai import OpenAI

client = OpenAI(
    api_key=os.getenv("DEEPSEEK_API_KEY", "sk-86b3b532876344e38b1412989fec387f"),
    base_url="https://api.deepseek.com"
)

def call_deepseek_json(prompt):
    for attempt in range(3):
        try:
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are a suspicious Security Auditor. You focus on exploitability, not just code presence. Return JSON only."},
                    {"role": "user", "content": prompt},
                ],
                response_format={'type': 'json_object'},
                temperature=0.1 # 降低随机性，保证审计严谨
            )
            return json.loads(response.choices[0].message.content)
        except: time.sleep(1)
    return None

def iris_dual_stage_audit(flow_data):
    # 阶段 1：严格的语义判定 (减少 Source/Sink 误判)
    spec_prompt = f"""
    Is this call a GENUINE security source or sink?
    Call: {flow_data['raw_call']}
    Note: Hardcoded strings are NEVER sources. Built-in constants are NEVER sinks.
    Return JSON: {{'is_source': bool, 'is_sink': bool, 'type': str}}
    """
    spec = call_deepseek_json(spec_prompt)
    if not spec or not (spec.get("is_source") or spec.get("is_sink")):
        return {"is_vulnerable": False}

    # 阶段 2：强制性的防御检查 (核心！用来压低 8 个 FP)
    verify_prompt = f"""
    [IRIS 专家审计 - 敏感度增强版]
    Sink: {flow_data['raw_call']}
    上下文:
    {flow_data['context']}

    审计逻辑重调：
    1. 寻找 Source：即使上下文没显示 request，但如果变量名类似 arg, param, data, input 且来源不明，假设其为用户输入。
    2. 检查防御：只有看到【明确且有效】的过滤（如 int(), isdigit(), 或严格的正则白名单）才判为 False。
    3. 逻辑链路：如果数据流经了多个函数或字典，只要没有被赋予固定的硬编码字符串，就视为潜在漏洞。

    返回 JSON: {{ "is_vulnerable": bool, "reasoning": "..." }}
    """
    return call_deepseek_json(verify_prompt)
