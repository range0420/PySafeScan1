import os, pandas as pd
from src.pipeline.iris_pipeline import IrisPipeline

def run_benchmark():
    # 使用你提供的 Key
    iris = IrisPipeline(api_key="sk-86b3b532876344e38b1412989fec387f")
    db_path = "iris-db"
    
    print("--- Stage 2: Running IRIS Symbolic Engine (Path Tracing) ---")
    paths = iris.extract_paths(db_path)
    
    # 加载 Benchmark 真值
    gt_df = pd.read_csv("tests/BenchmarkPython/expectedresults-0.1.csv", comment='#', header=None)
    gt_map = {str(row[0]).strip(): {"vuln": str(row[2]).lower() == 'true', "cwe": row[3]} for _, row in gt_df.iterrows()}

    stats = {"tp": 0, "fp": 0, "tn": 0, "fn": 0}

    # IRIS 的核心：基于路径的迭代验证
    for p in paths:
        filename = os.path.basename(p['file'])
        meta = gt_map.get(filename.replace(".py", ""))
        if not meta: continue

        # Stage 3: 上下文切片
        code_slice = iris.get_program_slice(p['file'], p['source_line'], p['sink_line'])
        
        # Stage 4: 神经验证
        verdict = iris.verify_path(code_slice, meta['cwe'])
        is_vuln = "$$ VULNERABILITY: YES" in verdict.upper()

        if is_vuln and meta['vuln']: stats["tp"] += 1; s = "✅ TP"
        elif is_vuln and not meta['vuln']: stats["fp"] += 1; s = "⚠️ FP"
        elif not is_vuln and not meta['vuln']: stats["tn"] += 1; s = "🛡️ TN"
        else: stats["fn"] += 1; s = "❌ FN"
        
        print(f"[{s}] {filename} (CWE-{meta['cwe']})")

    print(f"\nFinal Stats: {stats}")

if __name__ == "__main__":
    run_benchmark()
