import ast
import re
import os

class IRISFlowEngine(ast.NodeVisitor):
    def __init__(self, source_code):
        self.lines = source_code.splitlines()
        self.potential_flows = []
        self.assignments = {} # 追踪变量赋值 L号: {name: value_node}

    def _get_full_name(self, node):
        """递归获取完整名称，支持 a.b.c"""
        try:
            if isinstance(node, ast.Name): return node.id
            if isinstance(node, ast.Attribute):
                val = self._get_full_name(node.value)
                return f"{val}.{node.attr}" if val else node.attr
            if isinstance(node, ast.Subscript): return self._get_full_name(node.value)
            if isinstance(node, ast.Call): return self._get_full_name(node.func)
        except: pass
        return ""

    def _get_precise_context(self, var_names, call_lineno):
        context = []
        for var in var_names:
            if not var: continue
            root_var = var.split('.')[0]
            pattern = re.compile(rf'\b{re.escape(root_var)}\b')
            
            # 扩大搜索范围，并包含函数定义行 (def )
            for i, line in enumerate(self.lines):
                if pattern.search(line) or "def " in line:
                    context.append(f"L{i+1}: {line.strip()}")
        
        # 结果去重并排序
        return sorted(list(set(context)), key=lambda x: int(x.split(':')[0][1:]))

    def visit_Call(self, node):
        func_name = self._get_full_name(node.func)
        
        # 1. 过滤掉绝对无害的内置调用
        if not func_name or any(x in func_name for x in ['print', 'len', 'isinstance', 'type']):
            return

        # 2. 多行 Sink 关联：不仅看当前行，还要检查它是否是复合表达式的一部分
        # 向上追踪 3 行，向下追踪 2 行，构建“逻辑邻域”
        start_line = max(1, node.lineno - 3)
        end_line = min(len(self.lines), node.lineno + 2)
        neighborhood = [f"L{i}: {self.lines[i-1].strip()}" for i in range(start_line, end_line + 1)]

        # 3. 提取相关变量 (递归提取参数中的所有标识符)
        related_vars = set()
        for arg in node.args + node.keywords:
            for sub_node in ast.walk(arg):
                name = self._get_full_name(sub_node)
                if name: related_vars.add(name)

        # 4. 深度上下文切片：获取这些变量在【整个函数范围内】的生命周期
        # 这样即使 Source 在 50 行前，只要属于同一个变量追踪链，AI 就能看到
        full_context = self._get_precise_context(related_vars, node.lineno)
        
        # 合并切片：变量生命周期 + 邻域逻辑
        final_context = sorted(list(set(full_context + neighborhood)), key=lambda x: int(x.split(':')[0][1:]))

        self.potential_flows.append({
            'line': node.lineno,
            'raw_call': func_name,
            'neighborhood': "\n".join(neighborhood), # 新增：周围逻辑
            'context': "\n".join(final_context)
        })
        self.generic_visit(node)

def analyze_file(filepath):
    """带语法容错的分析入口"""
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            code = f.read()
        
        # 预处理：降级处理导致 ast 解析失败的 f-string
        processed_code = re.sub(r'f(["\'])(.*?)\1', r'\1f_string_placeholder\1', code)
        
        try:
            tree = ast.parse(processed_code)
        except:
            return [] # 解析彻底失败则跳过

        engine = IRISFlowEngine(code) # 上下文还是用原代码
        engine.visit(tree)
        return engine.potential_flows
    except:
        return []
