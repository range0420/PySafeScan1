"""
IRIS 级模糊匹配修复引擎
用于将 AI 生成的代码块精准替换回源文件
"""
import re
import difflib

def apply_fix_in_memory(current_content, line_num, full_context, new_code, is_block_fix=False, target_func_name=None):
    """
    通过模糊匹配算法在源码中定位并替换代码块
    """
    if not current_content or not new_code:
        return current_content
    
    # 清理 AI 返回的 Markdown 标签
    clean_code = re.sub(r'```python\s*|```', '', new_code).strip()
    
    lines = current_content.splitlines()
    # 提取用于定位的上下文行（去掉空白字符）
    context_lines = [l.strip() for l in full_context.splitlines() if l.strip()]
    
    if not context_lines:
        # 如果没有上下文参考，退回到简单的行号替换
        if 0 < line_num <= len(lines):
            lines[line_num - 1] = clean_code
        return "\n".join(lines)

    # 在漏洞点前后 50 行内搜索最匹配的代码块
    search_start = max(0, line_num - 50)
    search_end = min(len(lines), line_num + 50)
    
    best_match_idx = -1
    max_ratio = 0
    window_size = len(full_context.splitlines())
    
    for i in range(search_start, search_end - window_size + 2):
        current_window = [l.strip() for l in lines[i : i + window_size] if l.strip()]
        if not current_window: continue
            
        ratio = difflib.SequenceMatcher(None, context_lines, current_window).ratio()
        if ratio > max_ratio:
            max_ratio = ratio
            best_match_idx = i

    # 如果相似度超过 0.7，执行整块替换
    if max_ratio > 0.7:
        # 保持原始缩进
        indent_match = re.match(r'^\s*', lines[best_match_idx])
        base_indent = indent_match.group(0) if indent_match else ""
        
        fixed_lines = [(base_indent + l.lstrip()) for l in clean_code.splitlines()]
        lines[best_match_idx : best_match_idx + window_size] = fixed_lines
        print(f"  ✨ [Patcher] 匹配成功 (相似度: {max_ratio:.2f})，已重写代码块")
    else:
        # 匹配失败则只替换单行
        if 0 < line_num <= len(lines):
            lines[line_num - 1] = clean_code

    return "\n".join(lines)
