import ast

class TaintSlicer(ast.NodeVisitor):
    def __init__(self, target_node, source_vars):
        self.target_node = target_node
        self.source_vars = source_vars # 比如 {'user_input', 'raw_data'}
        self.path_slice = [] # 记录整个传播链条的代码

    def trace_back(self, node, tree):
        """
        逆向切片：从 Sink 点向上追溯所有影响该参数的赋值语句
        """
        # 提取当前节点涉及的变量
        current_vars = self._get_load_names(node)
        
        # 遍历 AST 寻找这些变量的定义
        for prev_node in ast.walk(tree):
            if isinstance(prev_node, ast.Assign):
                # 如果赋值的目标在我们的追踪变量里
                targets = [t.id for t in prev_node.targets if isinstance(t, ast.Name)]
                if any(var in targets for var in current_vars):
                    self.path_slice.insert(0, ast.unparse(prev_node))
                    # 递归追溯右值的变量
                    new_vars = self._get_load_names(prev_node.value)
                    current_vars.update(new_vars)
        
        # 加入 Sink 点本身
        self.path_slice.append(ast.unparse(self.target_node))
        return self.path_slice

    def _get_load_names(self, node):
        return {n.id for n in ast.walk(node) if isinstance(n, ast.Name) and isinstance(n.ctx, ast.Load)}
