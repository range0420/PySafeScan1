#!/usr/bin/env python3
"""应用最终修复"""

import ast

# 读取原文件
with open('src/core/taint_analysis_fixed.py', 'r') as f:
    content = f.read()

# 找到 _extract_tainted_from_expr 方法，添加对属性调用的处理
old_method = '''    def _extract_tainted_from_expr(self, node: ast.AST) -> List[str]:
        """从表达式中提取污点变量 - 改进版"""
        tainted = []
        
        if isinstance(node, ast.Name):
            if node.id in self.tainted_vars:
                tainted.append(node.id)
        
        elif isinstance(node, ast.BinOp):
            tainted.extend(self._extract_tainted_from_expr(node.left))
            tainted.extend(self._extract_tainted_from_expr(node.right))
        
        elif isinstance(node, ast.Call):
            # 对于函数调用，检查所有参数
            for arg in node.args:
                tainted.extend(self._extract_tainted_from_expr(arg))
            
            # 修复：检查这个调用是否是传播函数，返回结果是否被污染
            func_name = self._get_full_function_name(node.func)
            if self._is_propagator_function(func_name):
                # 如果这个传播函数的输入有污点，那么它的输出也可能被污染
                # 这里简化处理，实际需要更复杂的分析
                pass
        
        elif isinstance(node, ast.JoinedStr):  # f-string
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    tainted.extend(self._extract_tainted_from_expr(value.value))
        
        elif isinstance(node, ast.Subscript):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        elif isinstance(node, ast.UnaryOp):
            tainted.extend(self._extract_tainted_from_expr(node.operand))
        
        elif isinstance(node, ast.Attribute):
            # 修复：处理属性访问，如 cmd.strip()
            # 检查对象本身是否被污染
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        return list(set(tainted))  # 去重'''

new_method = '''    def _extract_tainted_from_expr(self, node: ast.AST) -> List[str]:
        """从表达式中提取污点变量 - 最终修复版"""
        tainted = []
        
        if isinstance(node, ast.Name):
            if node.id in self.tainted_vars:
                tainted.append(node.id)
        
        elif isinstance(node, ast.BinOp):
            tainted.extend(self._extract_tainted_from_expr(node.left))
            tainted.extend(self._extract_tainted_from_expr(node.right))
        
        elif isinstance(node, ast.Call):
            # 对于函数调用，检查所有参数
            for arg in node.args:
                tainted.extend(self._extract_tainted_from_expr(arg))
            
            # ⭐️ 关键修复：如果这是一个传播函数调用，检查调用对象是否被污染
            func_name = self._get_full_function_name(node.func)
            if self._is_propagator_function(func_name):
                # 检查调用对象（如 cmd.strip() 中的 cmd）
                if node.args:
                    # 第一个参数通常是调用对象
                    tainted.extend(self._extract_tainted_from_expr(node.args[0]))
        
        elif isinstance(node, ast.JoinedStr):  # f-string
            for value in node.values:
                if isinstance(value, ast.FormattedValue):
                    tainted.extend(self._extract_tainted_from_expr(value.value))
        
        elif isinstance(node, ast.Subscript):
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        elif isinstance(node, ast.UnaryOp):
            tainted.extend(self._extract_tainted_from_expr(node.operand))
        
        elif isinstance(node, ast.Attribute):
            # 检查对象本身是否被污染（如 cmd.strip 中的 cmd）
            tainted.extend(self._extract_tainted_from_expr(node.value))
        
        return list(set(tainted))  # 去重'''

# 替换方法
content = content.replace(old_method, new_method)

# 再改进 _process_propagator 方法
old_propagator_start = '''    def _process_propagator(self, node: ast.Call, func_name: str):
        """处理传播函数 - 修复测试4问题"""
        # 检查输入参数
        tainted_inputs = []
        for arg in node.args:
            # 提取污点变量
            extracted = self._extract_tainted_from_expr(arg)
            tainted_inputs.extend(extracted)'''
            
new_propagator_start = '''    def _process_propagator(self, node: ast.Call, func_name: str):
        """处理传播函数 - 最终修复版"""
        # 检查输入参数
        tainted_inputs = []
        for arg in node.args:
            # 提取污点变量
            extracted = self._extract_tainted_from_expr(arg)
            tainted_inputs.extend(extracted)
        
        # ⭐️ 关键修复：对于像 cmd.strip() 这样的方法调用，检查调用对象
        if isinstance(node.func, ast.Attribute):
            # 提取调用对象（如 cmd.strip() 中的 cmd）
            obj_tainted = self._extract_tainted_from_expr(node.func.value)
            tainted_inputs.extend(obj_tainted)'''

content = content.replace(old_propagator_start, new_propagator_start)

# 写回文件
with open('src/core/taint_analysis_fixed.py', 'w') as f:
    f.write(content)

print("✅ 已应用最终修复")
print("现在重新运行测试...")

# 重新运行测试
import subprocess
subprocess.run(['python', 'test_taint_fixed.py'])
