#!/usr/bin/env python3
"""测试真实世界漏洞模式"""

import sys
sys.path.insert(0, '.')

from src.core.taint_analysis_fixed import FixedTaintAnalyzer

test_cases = [
    {
        "name": "Web应用命令注入",
        "code": '''
import os
from flask import request

@app.route("/execute")
def execute_command():
    command = request.args.get('cmd', '')
    # 危险：直接执行用户输入
    os.system(command)
    return "Executed"
''',
        "expected_vulns": 1
    },
    {
        "name": "SQL注入漏洞",
        "code": '''
import sqlite3
from flask import request

def get_user():
    user_id = request.args.get('id', '')
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # 危险：字符串拼接SQL
    query = f"SELECT * FROM users WHERE id = {user_id}"
    cursor.execute(query)  # SQL注入！
    return cursor.fetchall()
''',
        "expected_vulns": 1
    },
    {
        "name": "反序列化漏洞",
        "code": '''
import pickle
import yaml
from flask import request

def load_data():
    data = request.get_data()
    # 危险：反序列化用户输入
    obj = pickle.loads(data)  # 反序列化漏洞
    return str(obj)
''',
        "expected_vulns": 1
    },
    {
        "name": "安全代码示例",
        "code": '''
import sqlite3

def safe_query(user_id):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # 安全：使用参数化查询
    cursor.execute("SELECT * FROM users WHERE id = ?", (user_id,))
    return cursor.fetchall()
''',
        "expected_vulns": 0
    }
]

print("🧪 真实世界漏洞模式测试")
print("=" * 60)

for test in test_cases:
    print(f"\n{test['name']}")
    print("-" * 40)
    
    analyzer = FixedTaintAnalyzer()
    result = analyzer.analyze_code(test['code'], 'test.py')
    
    vulns = len(result.get('vulnerability_paths', []))
    
    if vulns >= test['expected_vulns']:
        print(f"✅ 通过 - 发现 {vulns} 个漏洞")
        if vulns > 0:
            for path in result['vulnerability_paths']:
                print(f"   → {' → '.join(path)}")
    else:
        print(f"❌ 失败 - 期望 {test['expected_vulns']} 个漏洞，实际 {vulns} 个")
        print(f"污点变量: {result.get('tainted_variables', 0)}")
