#!/usr/bin/env python3
"""修复 sys.argv 检测"""

# 读取当前文件
with open('src/core/taint_analysis_fixed.py', 'r') as f:
    content = f.read()

# 我们需要添加一个新的 visitor 方法来处理属性访问
# 找到 visit_Call 方法的位置，在它之前添加 visit_Attribute 方法

# 首先添加 visit_Attribute 方法
attribute_method = '''
    def visit_Attribute(self, node: ast.Attribute):
        """Handle attribute access like sys.argv"""
        # Check for sys.argv
        if node.attr == 'argv':
            # Check if the object is 'sys'
            if isinstance(node.value, ast.Name) and node.value.id == 'sys':
                # Mark this as a taint source
                # We need to check if this is being assigned
                parent = getattr(node, 'parent', None)
                
                if isinstance(parent, ast.Subscript):
                    # Case: sys.argv[1] - array access
                    parent_parent = getattr(parent, 'parent', None)
                    if isinstance(parent_parent, ast.Assign):
                        for target in parent_parent.targets:
                            if isinstance(target, ast.Name):
                                var_name = target.id
                                self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                                print(f"[SOURCE-SYS] {var_name} <- sys.argv[{ast.dump(parent.slice) if hasattr(parent, 'slice') else '?'}] (command_line)")
                elif isinstance(parent, ast.Assign):
                    # Case: args = sys.argv
                    for target in parent.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id
                            self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                            print(f"[SOURCE-SYS] {var_name} <- sys.argv (command_line)")
        
        # Continue with normal visitation
        self.generic_visit(node)
'''

# 在 visit_Call 方法前插入
if 'def visit_Call(self, node: ast.Call):' in content:
    # 找到位置
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if 'def visit_Call(self, node: ast.Call):' in line:
            # 在这个方法前插入
            lines.insert(i, attribute_method)
            break
    
    content = '\n'.join(lines)

# 同时改进 _check_sys_argv_access 方法
# 找到这个方法并增强它
if 'def _check_sys_argv_access(self, node):' in content:
    # 用更完整的版本替换
    new_check_method = '''    def _check_sys_argv_access(self, node):
        """Check sys.argv access - enhanced version"""
        # This is now handled by visit_Attribute
        pass'''
    
    content = content.replace('def _check_sys_argv_access(self, node):', new_check_method)

# 写回文件
with open('src/core/taint_analysis_fixed.py', 'w') as f:
    f.write(content)

print("✅ 已添加 visit_Attribute 方法")

# 测试修复
print("\n测试 sys.argv 检测...")

test_code = '''import sys
import subprocess
command = sys.argv[1]
subprocess.run(command, shell=True)'''

# 直接导入测试
import ast
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional, Any

# 临时定义
class TaintType(Enum):
    USER_INPUT = "user_input"
    COMMAND_LINE = "command_line"
    WEB_INPUT = "web_input"
    ENVIRONMENT = "environment"
    FILE_INPUT = "file_input"
    NETWORK = "network"
    PROPAGATED = "propagated"
    PARAMETER = "parameter"

@dataclass
class TaintVariable:
    name: str
    line: int
    type: TaintType
    sources: List[str] = field(default_factory=list)

# 导入修复后的模块
import importlib.util
import sys as sys_module
spec = importlib.util.spec_from_file_location("FixedTaintAnalyzer", "src/core/taint_analysis_fixed.py")
module = importlib.util.module_from_spec(spec)

# 添加必要的类
module.TaintType = TaintType
module.TaintVariable = TaintVariable
module.ast = ast

sys_module.modules['fixed_taint_temp'] = module
spec.loader.exec_module(module)

# 创建分析器
analyzer = module.FixedTaintAnalyzer()
result = analyzer.analyze_code(test_code, 'test.py')

print(f"污点变量数: {result.get('tainted_variables', 0)}")
print(f"漏洞路径数: {len(result.get('vulnerability_paths', []))}")

if result.get('tainted_variables', 0) > 0:
    print("✅ sys.argv 检测成功!")
    print("污点变量:", list(analyzer.tainted_vars.keys()))
else:
    print("❌ sys.argv 检测仍然失败")
    print("可能需要进一步调试...")
