#!/usr/bin/env python3
"""
修复后的污点追踪测试
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.core.taint_analysis_fixed import FixedTaintAnalyzer

def test_fixed_analyzer():
    """测试修复后的分析器"""
    
    analyzer = FixedTaintAnalyzer()
    
    test_cases = [
        {
            "name": "1. 基本命令注入",
            "code": '''
import os
user_input = input("命令: ")
os.system(user_input)
''',
            "expected": True
        },
        {
            "name": "2. 直接调用危险函数",
            "code": '''
eval(input("代码: "))
''',
            "expected": True
        },
        {
            "name": "3. 赋值后使用",
            "code": '''
data = input("数据: ")
result = eval(data)
''',
            "expected": True
        },
        {
            "name": "4. 字符串操作传播",
            "code": '''
cmd = input("命令: ")
clean_cmd = cmd.strip()
os.system(clean_cmd)
''',
            "expected": True
        },
        {
            "name": "5. f-string传播",
            "code": '''
name = input("名字: ")
os.system(f"echo {name}")
''',
            "expected": True
        },
        {
            "name": "6. 多个赋值",
            "code": '''
x = input("输入: ")
y = x
z = y
eval(z)
''',
            "expected": True
        },
        {
            "name": "7. 安全代码",
            "code": '''
x = "安全字符串"
print(x)
y = 1 + 2
''',
            "expected": False
        },
    ]
    
    print("🧪 修复版污点分析器测试")
    print("=" * 60)
    
    passed = 0
    total = len(test_cases)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n{test_case['name']}")
        print("-" * 40)
        
        result = analyzer.analyze_code(test_case['code'], f"test_{i}.py")
        
        has_vuln = len(result.get('vulnerability_paths', [])) > 0
        
        status = "✅ 通过" if has_vuln == test_case['expected'] else "❌ 失败"
        print(status)
        
        if has_vuln != test_case['expected']:
            print(f"   期望: {'有漏洞' if test_case['expected'] else '无漏洞'}")
            print(f"   实际: {'有漏洞' if has_vuln else '无漏洞'}")
        
        # 显示详细信息
        if has_vuln:
            print(f"   发现 {len(result['vulnerability_paths'])} 条漏洞路径")
            for path in result['vulnerability_paths']:
                print(f"     → {' → '.join(path)}")
        else:
            print(f"   污点变量数: {result.get('tainted_variables', 0)}")
        
        if has_vuln == test_case['expected']:
            passed += 1
        
        # 重置分析器
        analyzer = FixedTaintAnalyzer()
    
    print(f"\n📊 测试结果: {passed}/{total} 通过")
    
    if passed == total:
        print("🎉 所有测试通过！修复成功。")
    else:
        print("⚠️  仍有测试失败，需要继续调试。")
    
    return passed == total

def demonstrate_complex_cases():
    """演示复杂案例"""
    print("\n" + "=" * 60)
    print("🚀 复杂案例演示")
    print("=" * 60)
    
    analyzer = FixedTaintAnalyzer()
    
    complex_cases = [
        {
            "name": "多步骤传播链",
            "code": '''
import os
import pickle

# 多个输入源
input1 = input("输入1: ")
input2 = input("输入2: ")

# 多步骤处理
step1 = input1.strip()
step2 = step2.replace("bad", "good")
step3 = f"命令: {step2}"

# 多个危险操作
os.system(step3)
pickle.loads(input2.encode())
'''
        },
        {
            "name": "类方法中的漏洞",
            "code": '''
import os

class Processor:
    def __init__(self):
        self.data = None
    
    def load_data(self):
        self.data = input("数据: ")
    
    def process(self):
        # 危险操作
        os.system(self.data)
    
    def safe_method(self):
        print("安全方法")

proc = Processor()
proc.load_data()
proc.process()
'''
        },
    ]
    
    for case in complex_cases:
        print(f"\n{case['name']}")
        print("-" * 40)
        
        result = analyzer.analyze_code(case['code'], f"complex_{case['name']}.py")
        
        print(f"污点变量: {result.get('tainted_variables', 0)}")
        print(f"漏洞路径: {len(result.get('vulnerability_paths', []))}")
        
        if result.get('vulnerability_paths'):
            print("发现的漏洞:")
            for path in result['vulnerability_paths']:
                print(f"  → {' → '.join(path)}")
        
        analyzer = FixedTaintAnalyzer()

def main():
    print("🔧 修复版污点追踪系统测试")
    print("=" * 60)
    
    success = test_fixed_analyzer()
    
    if success:
        demonstrate_complex_cases()
        
        print("\n" + "=" * 60)
        print("🏆 修复完成总结")
        print("=" * 60)
        
        print("\n✅ 已解决的问题:")
        print("1. AST parent属性设置")
        print("2. 函数名提取不完整")
        print("3. 污点源识别逻辑")
        print("4. 传播链跟踪算法")
        
        print("\n🎯 当前功能:")
        print("• 支持基本命令注入检测")
        print("• 支持字符串操作传播")
        print("• 支持f-string传播")
        print("• 支持多步骤传播链")
        print("• 支持类方法分析")
        
        print("\n🚀 使用修复版:")
        print("from src.core.taint_analysis_fixed import FixedTaintAnalyzer")
    else:
        print("\n❌ 修复未完全成功，需要继续调试")

if __name__ == "__main__":
    main()
