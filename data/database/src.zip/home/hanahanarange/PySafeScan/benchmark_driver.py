import os
import json
import pandas as pd
from config import *
from modules.templates import QLTemplate
from modules.scanner import PySafeScanner
from modules.auditor import PySafeAuditor
from modules.evaluator import PySafeEvaluator

def run_benchmark():
    os.makedirs(QUERY_DIR, exist_ok=True)
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    
    # 源代码目录
    BENCHMARK_SRC_DIR = "/home/hanahanarange/PySafeScan/tests/BenchmarkPython/testcode"
    
    evaluator = PySafeEvaluator(GROUND_TRUTH_PATH)
    scanner = PySafeScanner(DB_PATH, OUTPUT_DIR)
    auditor = PySafeAuditor(DEEPSEEK_API_KEY)
    
    final_predictions = {}
    test_cases = evaluator.df.head(10) 

    print(f"[*] IRIS-style Local Analysis started for {len(test_cases)} cases...")

    for _, row in test_cases.iterrows():
        test_id = row['test_name']
        cwe_code = f"CWE-{row['cwe']:03}"
        
        print(f"\n[>] Analyzing {test_id}...")

        # 强制在当前文件内部寻找流
        source_logic = "source instanceof DataFlow::ParameterNode"
        sink_logic = "exists(DataFlow::CallCfgNode c | sink = c.getArg(_))"
        
        ql_content = QLTemplate.PYTHON_TAINT_TRACKING.format(
            source_logic=source_logic, 
            sink_logic=sink_logic,
            test_id=test_id
        )
        
        query_file = os.path.join(QUERY_DIR, f"{test_id}.ql")
        with open(query_file, "w") as f:
            f.write(ql_content)

        try:
            # 运行查询
            json_res_path = scanner.run_query(query_file)
            with open(json_res_path, 'r') as f:
                scan_data = json.load(f)
        except Exception as e:
            print(f"    [!] Scanner error: {e}")
            continue

        potential_paths = scan_data.get("#select", {}).get("tuples", [])
        is_vulnerable_confirmed = False

        if not potential_paths:
            # 如果 Global 没结果，IRIS 会尝试直接读取文件源码进行 LLM 盲审（这是 IRIS 的兜底方案）
            print(f"    [-] Static Analysis failed to find flow. Triggering IRIS-Fallback Blind Audit...")
            actual_file_path = os.path.join(BENCHMARK_SRC_DIR, f"{test_id}.py")
            if os.path.exists(actual_file_path):
                # 盲审：直接把前 50 行代码喂给 LLM
                snippet = auditor.get_code_snippet(actual_file_path, 1, 50)
                audit_result = auditor.audit_path(cwe_code, snippet)
                if audit_result.get('is_vulnerable'):
                    is_vulnerable_confirmed = True
                    print(f"    [!] Fallback Audit CONFIRMED: Vulnerability found via semantic analysis!")
        else:
            print(f"    [+] Found {len(potential_paths)} local paths. Auditing...")
            for p in potential_paths:
                sink_loc_str = str(p[2])
                try:
                    line_num = int(sink_loc_str.split(':')[1])
                except:
                    line_num = 1
                
                actual_file_path = os.path.join(BENCHMARK_SRC_DIR, f"{test_id}.py")
                snippet = auditor.get_code_snippet(actual_file_path, line_num, SNIPPET_CONTEXT_SIZE)
                
                if snippet:
                    audit_result = auditor.audit_path(cwe_code, snippet)
                    if audit_result.get('is_vulnerable'):
                        is_vulnerable_confirmed = True
                        print(f"    [!] LLM Audit CONFIRMED at line {line_num}!")
                        break 

        final_predictions[test_id] = is_vulnerable_confirmed
        status = "VULNERABLE" if is_vulnerable_confirmed else "SAFE"
        print(f"    [*] Final Result: {status}")

    evaluator.evaluate(final_predictions)

if __name__ == "__main__":
    run_benchmark()
