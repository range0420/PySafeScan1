#!/usr/bin/env python3
"""
调试污点追踪系统
"""

import ast
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.core.taint_analysis import TaintAnalyzer

def debug_basic_case():
    """调试基本案例"""
    print("调试基本命令注入案例...")
    
    code = '''
import os
user_input = input("命令: ")
os.system(user_input)
'''
    
    print("代码:")
    print(code)
    
    # 手动解析AST
    tree = ast.parse(code)
    print("\nAST结构:")
    print(ast.dump(tree, indent=2))
    
    # 使用分析器
    analyzer = TaintAnalyzer()
    
    # 手动设置parent属性（帮助分析器理解结构）
    def set_parent(node, parent=None):
        node.parent = parent
        for child in ast.iter_child_nodes(node):
            set_parent(child, node)
    
    set_parent(tree)
    
    # 分析
    print("\n分析器输出:")
    analyzer.visit(tree)
    
    print(f"\n污点变量: {list(analyzer.tainted_vars.keys())}")
    print(f"漏洞路径: {analyzer.vulnerability_paths}")
    
    # 检查具体变量
    for var_name, var in analyzer.tainted_vars.items():
        print(f"\n变量 {var_name}:")
        print(f"  类型: {var.type}")
        print(f"  来源: {var.sources}")

def debug_function_extraction():
    """调试函数名提取"""
    print("\n调试函数名提取...")
    
    test_cases = [
        ('os.system("ls")', '应该提取: os.system'),
        ('input("test")', '应该提取: input'),
        ('eval("1+1")', '应该提取: eval'),
        ('pickle.loads(data)', '应该提取: pickle.loads'),
    ]
    
    for code_str, expected in test_cases:
        print(f"\n代码: {code_str}")
        print(f"期望: {expected}")
        
        try:
            node = ast.parse(code_str).body[0]
            if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
                call_node = node.value
                
                analyzer = TaintAnalyzer()
                func_name = analyzer._extract_function_name(call_node.func)
                print(f"实际提取: {func_name}")
                
                # 检查是否是污点源
                taint_type = analyzer._get_taint_type(func_name)
                print(f"污点类型: {taint_type}")
                
                # 检查是否是危险函数
                vuln_type = analyzer._get_vulnerability_type(func_name)
                print(f"漏洞类型: {vuln_type}")
        except Exception as e:
            print(f"错误: {e}")

def debug_taint_flow():
    """调试污点流"""
    print("\n调试污点流...")
    
    code = '''
x = input("输入: ")
y = x.strip()
z = f"echo {y}"
os.system(z)
'''
    
    print("代码:")
    print(code)
    
    analyzer = TaintAnalyzer()
    tree = ast.parse(code)
    
    # 设置parent
    for node in ast.walk(tree):
        for child in ast.iter_child_nodes(node):
            child.parent = node
    
    analyzer.visit(tree)
    
    print("\n分析结果:")
    print(f"污点变量: {analyzer.tainted_vars}")
    print(f"传播图: {analyzer.propagation_graph}")
    print(f"漏洞路径: {analyzer.vulnerability_paths}")

def main():
    print("🔍 污点追踪系统调试")
    print("=" * 60)
    
    debug_basic_case()
    debug_function_extraction()
    debug_taint_flow()

if __name__ == "__main__":
    main()
