import sqlite3

class DatabaseManager:
    def __init__(self, db_path):
        self.db = db_path

    def unsafe_query(self, user_id):
        conn = sqlite3.connect(self.db)
        cursor = conn.cursor()
        # 这里的漏洞需要看到 class 和 import 才能完美分析
        cursor.execute(f"SELECT * FROM users WHERE id={user_id}")
