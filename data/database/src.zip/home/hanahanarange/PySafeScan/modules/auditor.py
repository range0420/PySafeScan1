import os
import json
from openai import OpenAI

class PySafeAuditor:
    def __init__(self, api_key):
        # 确保使用最新的 OpenAI 客户端格式
        self.client = OpenAI(api_key=api_key, base_url="https://api.deepseek.com")

    def get_code_snippet(self, file_path, line_num, context_size):
        if not os.path.exists(file_path):
            return None
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                # 盲审时 line_num=1, context_size=50，基本覆盖整个 Benchmark 文件
                start = max(0, line_num - 1) 
                end = min(len(lines), line_num + context_size)
                return "".join(lines[start:end])
        except Exception as e:
            return f"Error reading file: {e}"

    def audit_path(self, cwe, snippet):
        # IRIS 论文核心 Prompt 风格：强调数据流来源与危险函数的关系
        system_msg = "你是一个网络安全专家，擅长发现代码中的脆弱性。你必须以严格的安全审计视角看待代码。"
        user_msg = f"""你是一个严谨的代码安全审计专家。
任务：分析代码是否存在 {cwe} 漏洞。

审计准则：
1. 路径分析：追踪数据从输入（如 request 参数）到 Sink 函数（如 open, execute）的流向。
2. 防御检查：特别注意中间是否有任何过滤、转义、白名单校验或路径规范化（如 os.path.abspath）。
3. 判定标准：只有当攻击者能通过输入直接导致非预期的文件读取/命令执行时，才判定为 true。

代码：
{snippet}

请严格按 JSON 返回：{{"is_vulnerable": true/false, "reason": "详细解释为什么是漏洞或为什么是安全的"}}"""
        try:
            response = self.client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": user_msg}
                ],
                response_format={ 'type': 'json_object' } # 强制 DeepSeek 输出 JSON
            )
            result = json.loads(response.choices[0].message.content)
            return result
        except Exception as e:
            print(f"    [!] LLM Audit Error: {e}")
            return {"is_vulnerable": False}
