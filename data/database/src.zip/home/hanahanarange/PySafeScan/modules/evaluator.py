import pandas as pd

class PySafeEvaluator:
    def __init__(self, ground_truth_path):
        # 读取答案，跳过首行注释
        self.df = pd.read_csv(ground_truth_path, comment='#', 
                             names=['test_name', 'category', 'is_vuln', 'cwe'])
        self.df['is_vuln'] = self.df['is_vuln'].map({'true': True, 'false': False})

    def evaluate(self, predictions):
        """
        predictions: dict -> { "BenchmarkTest00001": True, ... }
        """
        tp, fp, tn, fn = 0, 0, 0, 0
        
        for index, row in self.df.iterrows():
            test_name = row['test_name']
            actual = row['is_vuln']
            # 如果扫描器没发现漏洞，默认为 False
            predicted = predictions.get(test_name, False)
            
            if actual and predicted: tp += 1
            elif not actual and predicted: fp += 1
            elif not actual and not predicted: tn += 1
            elif actual and not predicted: fn += 1
            
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        accuracy = (tp + tn) / len(self.df)
        
        return {
            "Total": len(self.df),
            "TP": tp, "FP": fp, "TN": tn, "FN": fn,
            "Accuracy": f"{accuracy:.2%}",
            "Precision": f"{precision:.2%}",
            "Recall": f"{recall:.2%}"
        }
