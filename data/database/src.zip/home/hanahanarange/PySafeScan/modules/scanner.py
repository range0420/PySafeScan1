import subprocess
import os
import json

class PySafeScanner:
    def __init__(self, db_path, output_dir):
        self.db_path = db_path
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def run_query(self, query_path):
        bqrs_path = os.path.join(self.output_dir, "results.bqrs")
        json_path = os.path.join(self.output_dir, "results.json")
        
        # 1. 运行 QL
        subprocess.run([
            "codeql", "query", "run", 
            "--database", self.db_path, 
            "--output", bqrs_path, 
            query_path
        ], check=True)

        # 2. 解码 BQRS (IRIS 关键步骤)
        subprocess.run([
            "codeql", "bqrs", "decode", 
            bqrs_path, "--format=json", 
            "--output", json_path
        ], check=True)
        
        return json_path
