#!/usr/bin/env python3
"""更新污点源和危险函数定义"""

import re

# 读取原文件
with open('src/core/taint_analysis_fixed.py', 'r') as f:
    content = f.read()

# 1. 扩展source_functions定义
source_pattern = r"self\.source_functions = \{([^}]+)\}"
source_match = re.search(source_pattern, content, re.DOTALL)

if source_match:
    # 添加sys.argv等系统输入源
    new_sources = '''        # 扩展污点源定义
        self.source_functions = {
            'input': TaintType.USER_INPUT,
            'raw_input': TaintType.USER_INPUT,
            'argv': TaintType.COMMAND_LINE,
            'sys.argv': TaintType.COMMAND_LINE,
            'get': TaintType.WEB_INPUT,
            'post': TaintType.WEB_INPUT,
            'request': TaintType.WEB_INPUT,
            'args': TaintType.WEB_INPUT,
            'form': TaintType.WEB_INPUT,
            'environ': TaintType.ENVIRONMENT,
            'os.environ': TaintType.ENVIRONMENT,
            'getenv': TaintType.ENVIRONMENT,
            'os.getenv': TaintType.ENVIRONMENT,
            'read': TaintType.FILE_INPUT,
            'open': TaintType.FILE_INPUT,
            'recv': TaintType.NETWORK,
            'recvfrom': TaintType.NETWORK,
            'getcwd': TaintType.FILE_INPUT,
            'os.getcwd': TaintType.FILE_INPUT,
            'listdir': TaintType.FILE_INPUT,
            'os.listdir': TaintType.FILE_INPUT,
        }'''
    
    content = re.sub(source_pattern, new_sources, content, flags=re.DOTALL)

# 2. 扩展sink_functions定义
sink_pattern = r"self\.sink_functions = \{([^}]+)\}"
sink_match = re.search(sink_pattern, content, re.DOTALL)

if sink_match:
    # 添加SQL注入相关危险函数
    new_sinks = '''        # 扩展危险函数
        self.sink_functions = {
            'os.system': 'command_injection',
            'os.popen': 'command_injection',
            'os.spawn': 'command_injection',
            'subprocess.call': 'command_injection',
            'subprocess.Popen': 'command_injection',
            'subprocess.run': 'command_injection',
            'subprocess.check_call': 'command_injection',
            'subprocess.check_output': 'command_injection',
            'eval': 'code_injection',
            'exec': 'code_injection',
            'compile': 'code_injection',
            '__import__': 'code_injection',
            'pickle.loads': 'deserialization',
            'pickle.load': 'deserialization',
            'yaml.load': 'deserialization',
            'yaml.safe_load': 'deserialization',  # safe_load也有风险
            'marshal.loads': 'deserialization',
            'open': 'path_traversal',
            'execfile': 'code_injection',
            # SQL注入相关
            'execute': 'sql_injection',
            'cursor.execute': 'sql_injection',
            'executemany': 'sql_injection',
            'sqlite3.connect.execute': 'sql_injection',
            'connection.execute': 'sql_injection',
            'sqlite3.Cursor.execute': 'sql_injection',
            'mysql.connector.execute': 'sql_injection',
            'psycopg2.execute': 'sql_injection',
            'pymysql.execute': 'sql_injection',
            # Web相关
            'render_template_string': 'ssti',
            'render': 'ssti',
            'Template': 'ssti',
            'flask.render_template_string': 'ssti',
            'django.template.Template': 'ssti',
        }'''
    
    content = re.sub(sink_pattern, new_sinks, content, flags=re.DOTALL)

# 3. 添加属性访问的特殊处理（如 sys.argv）
# 在 _get_full_function_name 方法后添加一个辅助方法
helper_method = '''
    def _is_sys_argv(self, node) -> bool:
        """检查是否是 sys.argv 访问"""
        if isinstance(node, ast.Attribute):
            if node.attr == 'argv':
                # 检查对象部分
                if isinstance(node.value, ast.Name) and node.value.id == 'sys':
                    return True
                elif isinstance(node.value, ast.Attribute):
                    # 可能是 os.sys.argv 等
                    full_name = self._get_full_function_name(node.value)
                    if full_name.endswith('.sys'):
                        return True
        return False'''

# 在 _get_full_function_name 方法后插入
insert_point = "        return \"\""
if insert_point in content:
    content = content.replace(insert_point, helper_method + "\n        return \"\"")

# 4. 在 visit_Call 方法中添加 sys.argv 处理
call_method_start = "    def visit_Call(self, node: ast.Call):"
if call_method_start in content:
    # 在方法开头添加特殊处理
    enhanced_call = '''    def visit_Call(self, node: ast.Call):
        """分析函数调用 - 核心逻辑，添加sys.argv处理"""
        # 先处理sys.argv等特殊情况
        self._check_special_sources(node)
        
        # 原来的逻辑'''
    
    content = content.replace(call_method_start, enhanced_call)

# 5. 添加 _check_special_sources 方法
special_method = '''
    def _check_special_sources(self, node: ast.Call):
        """检查特殊污点源如 sys.argv 的子属性访问"""
        # 检查是否是类似 sys.argv[1] 的调用
        if isinstance(node.func, ast.Subscript):
            # 检查下标访问的对象
            if self._is_sys_argv(node.func.value):
                # sys.argv[1] 是污点源
                parent = getattr(node, 'parent', None)
                if isinstance(parent, ast.Assign):
                    for target in parent.targets:
                        if isinstance(target, ast.Name):
                            var_name = target.id
                            self.tainted_vars[var_name] = TaintVariable(var_name, node.lineno, TaintType.COMMAND_LINE)
                            print(f"[SOURCE-SYS] {var_name} ← sys.argv[{ast.dump(node.func.slice)}] (command_line)")'''

# 在类定义中找到合适的位置插入
class_end_pattern = r"class FixedTaintAnalyzer\(ast\.NodeVisitor\):"
if class_end_pattern in content:
    # 在 __init__ 方法后插入
    init_end = "        self._direct_source_nodes: Dict[ast.Call, str] = {}"
    if init_end in content:
        # 在 __init__ 结束后插入新方法
        insert_after = init_end + "\n    "
        content = content.replace(insert_after, init_end + "\n\n    " + special_method + "\n    ")

# 写回文件
with open('src/core/taint_analysis_fixed.py', 'w') as f:
    f.write(content)

print("✅ 已更新污点源和危险函数定义")

# 测试更新
print("\n🔍 测试更新后的分析器...")

test_code = '''
import subprocess
import sys

def test():
    user_cmd = sys.argv[1]
    subprocess.run(user_cmd, shell=True)
    
    user_id = input("ID: ")
    query = f"SELECT * FROM users WHERE id = {user_id}"
    print(query)  # 模拟SQL执行
'''

# 直接导入测试
import ast
from enum import Enum
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple, Optional, Any

# 临时定义必要的类
class TaintType(Enum):
    USER_INPUT = "user_input"
    COMMAND_LINE = "command_line"
    WEB_INPUT = "web_input"
    ENVIRONMENT = "environment"
    FILE_INPUT = "file_input"
    NETWORK = "network"
    PROPAGATED = "propagated"
    PARAMETER = "parameter"

@dataclass
class TaintVariable:
    name: str
    line: int
    type: TaintType
    sources: List[str] = field(default_factory=list)

# 动态导入修复后的类
import importlib.util
spec = importlib.util.spec_from_file_location("FixedTaintAnalyzer", "src/core/taint_analysis_fixed.py")
module = importlib.util.module_from_spec(spec)

# 添加必要的类到模块命名空间
module.TaintType = TaintType
module.TaintVariable = TaintVariable

spec.loader.exec_module(module)

# 创建分析器实例
analyzer = module.FixedTaintAnalyzer()
result = analyzer.analyze_code(test_code, 'test.py')

print(f"\n分析结果:")
print(f"污点变量: {result.get('tainted_variables', 0)}")
print(f"漏洞路径: {len(result.get('vulnerability_paths', []))}")

if result.get('tainted_variables', 0) > 0:
    print("✅ sys.argv 现在被正确识别为污点源")
else:
    print("❌ sys.argv 识别仍有问题")

# 运行完整测试验证没有破坏原有功能
print("\n" + "=" * 60)
print("运行完整测试套件验证...")
import subprocess
subprocess.run(['python', 'test_taint_fixed.py'])
