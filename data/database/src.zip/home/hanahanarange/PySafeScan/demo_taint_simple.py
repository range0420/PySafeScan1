#!/usr/bin/env python3
"""
污点追踪演示 - 可运行版本
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.core.taint_analysis import TaintAnalyzer, AdvancedTaintTracker
from src.visualization.taint_visualizer import SimpleTaintVisualizer

def demo_basic_taint():
    """演示基本污点追踪"""
    print("=" * 60)
    print("🧪 污点追踪演示 - 基本功能")
    print("=" * 60)
    
    analyzer = TaintAnalyzer()
    
    # 示例1：简单的命令注入
    code1 = '''
user_input = input("输入命令: ")
os.system(user_input)
'''
    
    print("\n1. 简单命令注入检测:")
    print(code1.strip())
    
    result1 = analyzer.analyze_code(code1, "demo1.py")
    
    visualizer = SimpleTaintVisualizer()
    visualizer.generate_text_report(result1)
    
    if result1.get('vulnerability_paths'):
        print("✅ 发现命令注入漏洞！")
    else:
        print("❌ 未发现漏洞")
    
    # 示例2：复杂的传播链
    code2 = '''
filename = input("文件名: ")
cleaned = filename.strip()
full_path = "/home/user/" + cleaned
content = open(full_path, "r")
'''
    
    print("\n" + "=" * 40)
    print("2. 复杂传播链检测:")
    print(code2.strip())
    
    result2 = analyzer.analyze_code(code2, "demo2.py")
    visualizer.generate_text_report(result2)
    
    # 示例3：多步骤传播
    code3 = '''
data = input("输入数据: ")
step1 = data.strip()
step2 = step1.replace("bad", "good")
step3 = step2.upper()
eval(step3)
'''
    
    print("\n" + "=" * 40)
    print("3. 多步骤传播检测:")
    print(code3.strip())
    
    result3 = analyzer.analyze_code(code3, "demo3.py")
    visualizer.generate_text_report(result3)

def demo_project_analysis():
    """演示项目级分析"""
    print("\n" + "=" * 60)
    print("🚀 污点追踪演示 - 项目级分析")
    print("=" * 60)
    
    # 创建测试项目
    os.makedirs("test_taint_project", exist_ok=True)
    
    with open("test_taint_project/main.py", "w") as f:
        f.write('''
import utils

def main():
    user_data = input("输入数据: ")
    result = utils.process(user_data)
    print(f"结果: {result}")

if __name__ == "__main__":
    main()
''')
    
    with open("test_taint_project/utils.py", "w") as f:
        f.write('''
import os

def process(data):
    # 危险操作
    command = "echo " + data
    os.system(command)
    
    # 文件操作
    filename = data + ".txt"
    with open(filename, "w") as f:
        f.write("test")
    
    return "完成"
''')
    
    print("项目结构:")
    print("test_taint_project/")
    print("  ├── main.py")
    print("  └── utils.py")
    
    # 执行项目分析
    tracker = AdvancedTaintTracker()
    results = tracker.analyze_project("test_taint_project")
    
    summary = results['summary']
    print(f"\n📊 分析结果:")
    print(f"  扫描文件: {summary['total_files']}")
    print(f"  发现漏洞: {summary['total_vulnerabilities']}")
    print(f"  有漏洞文件: {summary['files_with_vulns']}")
    
    if summary['vulnerability_types']:
        print("  漏洞类型:")
        for vuln_type, count in summary['vulnerability_types'].items():
            print(f"    {vuln_type}: {count}")
    
    # 清理
    import shutil
    if os.path.exists("test_taint_project"):
        shutil.rmtree("test_taint_project")

def main():
    print("🚀 PySafeScan Pro - 污点追踪系统演示")
    print("全国信息安全竞赛 - 核心功能展示")
    print("=" * 60)
    
    demo_basic_taint()
    demo_project_analysis()
    
    print("\n" + "=" * 60)
    print("🎉 演示完成!")
    print("=" * 60)
    
    print("\n💡 竞赛亮点:")
    print("1. ✅ 完整的污点追踪算法实现")
    print("2. ✅ 支持复杂传播链分析")  
    print("3. ✅ 项目级多文件分析")
    print("4. ✅ 多种报告格式输出")
    print("5. ✅ 无需外部依赖，纯Python实现")

if __name__ == "__main__":
    main()
