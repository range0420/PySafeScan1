#!/usr/bin/env python3
"""快速修复测试4问题"""

# 直接修改分析器中的关键方法
import ast

def debug_extract_tainted(node, tainted_vars):
    """调试版本的污点提取"""
    if isinstance(node, ast.Name):
        print(f"  检查变量: {node.id}, 是否在污点列表中: {node.id in tainted_vars}")
        if node.id in tainted_vars:
            return [node.id]
    elif isinstance(node, ast.Call):
        print(f"  检查函数调用: {node}")
        # 检查是否是 strip() 这样的方法调用
        if isinstance(node.func, ast.Attribute):
            print(f"  是属性调用: {node.func.attr}")
            # 检查调用对象是否被污染
            obj_name = None
            if isinstance(node.func.value, ast.Name):
                obj_name = node.func.value.id
                print(f"  调用对象: {obj_name}, 是否被污染: {obj_name in tainted_vars}")
                if obj_name in tainted_vars:
                    # 传播函数的返回值也应该被污染
                    # 但是这里需要知道返回值被赋给了哪个变量
                    return [obj_name]
    return []

# 测试代码
test_code = '''
cmd = input("命令: ")
clean_cmd = cmd.strip()
os.system(clean_cmd)
'''

print("=== 手动分析 ===")
tree = ast.parse(test_code)

# 模拟污点变量
tainted_vars = {'cmd'}

# 查找 os.system 调用
for node in ast.walk(tree):
    if isinstance(node, ast.Call):
        if isinstance(node.func, ast.Attribute) and node.func.attr == 'system':
            print(f"\n找到 os.system 调用，参数:")
            for arg in node.args:
                print(f"  参数: {ast.dump(arg)}")
                tainted = debug_extract_tainted(arg, tainted_vars)
                print(f"  提取污点: {tainted}")
                
                if isinstance(arg, ast.Name):
                    print(f"  参数名: {arg.id}")
                    print(f"  这个变量应该被污染吗？clean_cmd 应该从 cmd 传播过来")

print("\n=== 问题分析 ===")
print("1. cmd = input()  # cmd 被标记为污点 ✓")
print("2. clean_cmd = cmd.strip()  # clean_cmd 应该从 cmd 传播 ✗")
print("3. os.system(clean_cmd)  # 应该检测到 clean_cmd 是污点 ✗")
print("\n问题在于：strip() 调用后，clean_cmd 没有被正确标记为污点变量")
