import os
import requests
from flask import Flask, request

app = Flask(__name__)

@app.route("/proxy")
def proxy():
    # 漏洞 1: SSRF
    # 攻击者可以输入 http://169.254.169.254/latest/meta-data/ 获取云端凭证
    url = request.args.get("url")
    return requests.get(url).text

@app.route("/download")
def download():
    # 漏洞 2: 路径穿越 (Path Traversal)
    # 攻击者可以输入 ../../../etc/passwd
    filename = request.args.get("file")
    with open(os.path.join("/var/www/static", filename), "r") as f:
        return f.read()

if __name__ == "__main__":
    app.run()
