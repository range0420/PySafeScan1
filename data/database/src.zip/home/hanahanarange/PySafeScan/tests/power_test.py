import os
from flask import request

# 场景 1：复合字典追踪 (request.form)
def complex_data():
    data = request.form['cmd'] # 复合结构识别
    os.system(data)

# 场景 2：跨函数参数传递 (虽然目前在单文件内，但模拟了函数边界)
def execute_worker(task):
    os.system(task)

def task_manager():
    user_task = input()
    execute_worker(user_task) # 跨函数参数流入

# 场景 3：净化阻断逻辑
def sanitized_logic():
    p_id = request.args.get('id')
    safe_id = int(p_id) # 符号引擎应该在此处切断污染，不提交给 AI
    os.system(f"echo {safe_id}")
