import os

# 场景 1：真正的漏洞（应该报警）
user_input = input("请输入命令：")
cmd = "ls " + user_input
os.system(cmd) 

# 场景 2：变量传递后的漏洞（应该报警）
raw_data = input()
middle_man = raw_data
os.system(middle_man)

# 场景 3：硬编码的字符串（不该报警！旧版会误报，新版应忽略）
safe_cmd = "ls -l /tmp"
os.system(safe_cmd)

# 场景 4：被重新赋值为安全字符串（不该报警！）
tainted = input()
tainted = "fixed_string"
os.system(tainted)
