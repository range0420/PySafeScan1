import os
import sqlite3
from flask import request

# 场景 1：SQL 注入（应该报警）
def login():
    username = request.form['username']
    db = sqlite3.connect("users.db")
    db.execute("SELECT * FROM users WHERE name = '" + username + "'")

# 场景 2：被 int() 净化后的命令注入（不该报警！IRIS 应该能识别出这是安全的）
def safe_process():
    user_id = input("Enter ID: ")
    clean_id = int(user_id) # 符号引擎会识别出 int 是净化器
    os.system(f"echo Processing {clean_id}")

# 场景 3：路径穿越（应该报警）
def read_file():
    filename = request.args.get("file")
    with open(f"/var/www/data/{filename}", "r") as f:
        print(f.read())

# 场景 4：多变量转手（应该报警）
def mixed_data():
    raw = input()
    a = raw
    b = a
    c = b
    os.system(c)

