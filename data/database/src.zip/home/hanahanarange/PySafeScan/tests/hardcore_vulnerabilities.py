import os
import sqlite3
import subprocess

def identity_transform(data):
    """模拟复杂的中间转换函数"""
    inter_a = data
    inter_b = [inter_a]
    return inter_b[0]

def test_obfuscated_cmd_injection():
    """
    场景 1: 混淆式命令注入
    测试点：多层包装 + 别名传递
    普通扫描器常因为变量名改变和函数返回而跟丢污点。
    """
    raw_input = input("Enter node: ")
    # 污点经过函数包装和列表解包
    tainted_val = identity_transform(raw_input)
    
    # 故意制造一个干扰项
    clean_val = "ls"
    
    # 拼接注入
    cmd = f"{clean_val} {tainted_val}"
    
    # 模拟一个看似检查逻辑，实则无效的防御
    if len(cmd) > 1000:
        return
        
    os.system(cmd) # SINK

def test_false_positive_scrubbing():
    """
    场景 2: 误报清洗测试
    测试点：变量被重新赋值为常量（Killer Assignment）
    系统应该识别出：尽管变量名曾被污染，但此时已被“洗白”。
    """
    user_data = input("Malicious input: ")
    x = user_data
    
    # 关键点：这里 x 被洗白了
    x = "safe_static_file.txt"
    
    with open(x, 'r') as f: # 这里的 SINK 应该是安全的
        print(f.read())

def test_logic_bypass_ssrf():
    """
    场景 3: 逻辑漏洞（SSRF）
    测试点：AI 对伪防御的识别能力
    开发者尝试检查 "http"，但逻辑写错了。
    """
    import requests
    target = input("URL: ")
    
    # 伪防御：仅仅检查是否以 http 开头，无法防御 127.0.0.1 或内网探测
    if target.startswith("http"):
        # AI 赋能应该识别出这种逻辑不足以防御 SSRF
        requests.get(target)

def test_cross_function_sqli(user_id):
    """
    场景 4: 跨函数参数传递
    测试点：如果输入作为参数传进函数，系统是否能识别函数头部的污染。
    """
    db = sqlite3.connect("users.db")
    # 假设 user_id 是从外部入口传入的污染源
    query = "SELECT * FROM profile WHERE id = " + user_id
    db.execute(query)
