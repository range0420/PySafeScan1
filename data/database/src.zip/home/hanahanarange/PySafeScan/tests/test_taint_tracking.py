"""
污点追踪测试 - 验证核心算法准确性
"""

import unittest
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from core.taint_analysis import TaintAnalysis

class TestTaintTracking(unittest.TestCase):
    
    def setUp(self):
        self.analyzer = TaintAnalysis()
    
    def test_basic_taint_source(self):
        """测试基本污点源识别"""
        code = '''
user_input = input("请输入: ")
result = user_input
'''
        
        tree = ast.parse(code)
        self.analyzer.visit(tree)
        
        self.assertIn('user_input', self.analyzer.tainted_vars)
        self.assertEqual(self.analyzer.tainted_vars['user_input'].taint_type, 'user_input')
    
    def test_command_injection_chain(self):
        """测试命令注入链"""
        code = '''
filename = input("文件名: ")
command = "cat " + filename
os.system(command)
'''
        
        tree = ast.parse(code)
        self.analyzer.visit(tree)
        
        # 应该发现污点传播链
        self.assertGreater(len(self.analyzer.vulnerability_paths), 0)
    
    def test_cross_file_analysis(self):
        """测试跨文件分析（模拟）"""
        # 创建模拟的跨文件场景
        pass
    
    def test_propagation_tracking(self):
        """测试污点传播跟踪"""
        code = '''
data = input("输入: ")
processed = data.strip()
result = processed.upper()
'''
        
        tree = ast.parse(code)
        self.analyzer.visit(tree)
        
        # 检查传播链
        self.assertIn('data', self.analyzer.tainted_vars)
        self.assertIn('processed', self.analyzer.tainted_vars)
        self.assertIn('result', self.analyzer.tainted_vars)
    
    def test_false_positive_prevention(self):
        """测试误报预防"""
        code = '''
# 安全的使用
safe_data = "constant string"
os.system("echo hello")  # 常量，安全
'''
        
        tree = ast.parse(code)
        self.analyzer.visit(tree)
        
        # 不应该误报
        self.assertEqual(len(self.analyzer.vulnerability_paths), 0)

if __name__ == '__main__':
    unittest.main()
