import os

def test_logic():
    user_data = input("Enter something: ")
    # 强大的检测器应该识别出这个逻辑分支是安全的
    if user_data.isalnum():
        os.system("echo " + user_data) 
    else:
        # 这个分支也是安全的，因为数据流被截断了
        print("Invalid data")

def test_vulnerable():
    # 这个分支应该被检测出来
    raw = input("Enter raw: ")
    os.system("ls " + raw)
