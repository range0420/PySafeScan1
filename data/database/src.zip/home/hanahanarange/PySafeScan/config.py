import os

# 基础路径配置
BASE_DIR = "/home/hanahanarange/PySafeScan"
SRC_DIR = os.path.join(BASE_DIR, "tests/BenchmarkPython/testcode")
DB_PATH = os.path.join(BASE_DIR, "data/database")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")
QUERY_DIR = os.path.join(BASE_DIR, "queries")

# 答案文件路径 (你刚刚提供的那个地址)
GROUND_TRUTH_PATH = os.path.join(BASE_DIR, "tests/BenchmarkPython/expectedresults-0.1.csv")

# LLM 配置
DEEPSEEK_API_KEY = "sk-86b3b532876344e38b1412989fec387f"
DEEPSEEK_URL = "https://api.deepseek.com/v1/chat/completions"

# 审计配置
SNIPPET_CONTEXT_SIZE = 15  # Benchmark 代码嵌套深，建议调大
