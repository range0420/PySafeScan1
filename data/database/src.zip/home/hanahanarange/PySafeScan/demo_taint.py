#!/usr/bin/env python3
"""
污点追踪演示 - 展示竞赛级功能
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.core.taint_analysis import TaintAnalysis, AdvancedTaintTracker
from src.visualization.taint_visualizer import TaintVisualizer

def demonstrate_basic_taint():
    """演示基本污点追踪"""
    print("=" * 60)
    print("🧪 污点追踪演示 - 基本功能")
    print("=" * 60)
    
    analyzer = TaintAnalysis()
    
    # 示例1：简单的命令注入
    code1 = '''
user_input = input("输入命令: ")
os.system(user_input)
'''
    
    print("\n1. 简单命令注入检测:")
    print(code1.strip())
    
    import ast
    tree1 = ast.parse(code1)
    analyzer.visit(tree1)
    
    if analyzer.vulnerability_paths:
        print("✅ 发现漏洞路径:")
        for path in analyzer.vulnerability_paths:
            print(f"   → {' → '.join(path)}")
    else:
        print("❌ 未发现漏洞")
    
    # 示例2：复杂的传播链
    code2 = '''
filename = input("文件名: ")
cleaned = filename.strip()
full_path = "/home/user/" + cleaned
content = open(full_path, "r").read()
'''
    
    print("\n2. 复杂传播链检测:")
    print(code2.strip())
    
    tree2 = ast.parse(code2)
    analyzer = TaintAnalysis()  # 重置分析器
    analyzer.visit(tree2)
    
    print(f"污点变量数: {len(analyzer.tainted_vars)}")
    for var_name, var in analyzer.tainted_vars.items():
        print(f"  {var_name}: {var.taint_type}")

def demonstrate_advanced_features():
    """演示高级功能"""
    print("\n" + "=" * 60)
    print("🚀 污点追踪演示 - 高级功能")
    print("=" * 60)
    
    # 创建测试项目结构
    os.makedirs("test_project", exist_ok=True)
    
    # 创建多个测试文件
    with open("test_project/main.py", "w") as f:
        f.write('''
import utils

def main():
    user_data = input("输入: ")
    result = utils.process_data(user_data)
    print(result)

if __name__ == "__main__":
    main()
''')
    
    with open("test_project/utils.py", "w") as f:
        f.write('''
import os

def process_data(data):
    # 危险处理
    command = "echo " + data.strip()
    os.system(command)
    return "处理完成"
''')
    
    print("\n项目结构:")
    print("test_project/")
    print("  ├── main.py")
    print("  └── utils.py")
    
    # 执行项目级分析
    tracker = AdvancedTaintTracker()
    results = tracker.analyze_project("test_project")
    
    print(f"\n分析结果:")
    print(f"  扫描文件数: {results['summary']['total_files']}")
    print(f"  发现漏洞数: {results['summary']['total_vulnerabilities']}")
    
    if results['summary']['vulnerability_types']:
        print("  漏洞类型分布:")
        for vuln_type, count in results['summary']['vulnerability_types'].items():
            print(f"    {vuln_type}: {count}")

def demonstrate_visualization():
    """演示可视化功能"""
    print("\n" + "=" * 60)
    print("📊 污点追踪演示 - 数据可视化")
    print("=" * 60)
    
    # 模拟分析数据
    sample_data = {
        'taint_data': {
            'graph_nodes': ['user_input', 'cleaned', 'command', 'os.system'],
            'graph_edges': [
                ('user_input', 'cleaned'),
                ('cleaned', 'command'), 
                ('command', 'os.system')
            ]
        },
        'vulnerability_paths': [
            ['user_input', 'cleaned', 'command', 'os.system()']
        ],
        'vulnerability_types': {
            'command_injection': 2,
            'path_traversal': 1,
            'deserialization': 1
        }
    }
    
    visualizer = TaintVisualizer()
    
    # 生成仪表板
    print("\n生成交互式仪表板...")
    visualizer.export_dashboard(sample_data, "taint_dashboard.html")
    
    print("✅ 可视化文件已生成:")
    print("  - taint_dashboard.html (交互式HTML)")
    print("  - taint_dashboard.png (静态图片)")

def main():
    print("🚀 PySafeScan Pro - 污点追踪系统演示")
    print("全国信息安全竞赛 - 核心功能展示")
    print("=" * 60)
    
    demonstrate_basic_taint()
    demonstrate_advanced_features()
    demonstrate_visualization()
    
    print("\n" + "=" * 60)
    print("🎉 演示完成!")
    print("=" * 60)
    print("\n💡 竞赛亮点:")
    print("1. 完整的污点追踪算法")
    print("2. 跨文件数据流分析")
    print("3. 专业的数据可视化")
    print("4. 低误报率设计")
    
    # 清理
    import shutil
    if os.path.exists("test_project"):
        shutil.rmtree("test_project")

if __name__ == "__main__":
    main()
